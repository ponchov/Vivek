-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: q3vtafztappqbpzn.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: uyfpb5wx6tnyzrhm
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `potential_participates`
--

DROP TABLE IF EXISTS `potential_participates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `potential_participates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `license_id` int(11) NOT NULL,
  `company_name` varchar(300) NOT NULL,
  `person_name` varchar(300) NOT NULL,
  `person_phone` varchar(50) NOT NULL,
  `person_email` varchar(300) NOT NULL,
  `message` text NOT NULL,
  `file` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `thread_id` varchar(300) NOT NULL DEFAULT '',
  `type` int(11) NOT NULL,
  `display` int(11) NOT NULL DEFAULT '0',
  `create_date` datetime NOT NULL,
  `send_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `potential_participates`
--

LOCK TABLES `potential_participates` WRITE;
/*!40000 ALTER TABLE `potential_participates` DISABLE KEYS */;
INSERT INTO `potential_participates` VALUES (1,106,'','john','2147483647','webmaster@synpat.com','hiii, how r u?','https://docs.google.com/file/d/0B-7JHq4pougDb3lhcy1hNWI0SHM/edit?usp=drivesdk',3.00,'',0,0,'2015-04-29 00:39:32','2015-04-30 13:00:58'),(2,106,'','Dudu Daada','415085858588','uzi@synpt.com',' As you may know, the participation fee is calculated by dividing the Seller\'s Upfront Price by the number of Participan','https://docs.google.com/file/d/0B-7JHq4pougDS0p5ZGVYNUR4czQ/edit?usp=drivesdk',0.52,'',0,0,'2015-04-30 14:18:47','2015-04-30 14:21:29'),(3,106,'','AS','31312','webmaster@synpat.com','ASD','https://docs.google.com/file/d/0B-7JHq4pougDSUx3RDA2WEptUTg/edit?usp=drivesdk',0.00,'',0,0,'2015-05-03 23:44:17','2015-05-05 14:03:38'),(4,106,'','qwe','1233','vivekkapoor99@gmail.com','wq','https://docs.google.com/file/d/0B-7JHq4pougDNXlMOFJLLWItUzA/edit?usp=drivesdk',0.00,'',0,0,'2015-05-03 23:31:46','2015-05-05 14:04:44'),(5,106,'','asd','7508358057','er.vivek2512@gmail.com','dasd','https://docs.google.com/document/d/1U2Dhk-Vjt46YITzSW_8ZYZZosTi-JDygaSshabH7uRU/edit?usp=drivesdk',0.00,'14d28afb5a82fa5f',0,0,'2015-05-03 23:44:56','2015-05-06 05:00:26'),(15,118,'Diesel','Russel Arnold','415-860-8412','webmaster@synpat.com','This is my message for Participate.','https://drive.google.com/file/d/0B-7JHq4pougDUzVQLThqSzZOdFU/view?usp=drivesdk',0.20,'',0,0,'2015-09-10 14:13:47','2015-09-10 14:14:49'),(16,118,'Cisco corp.','John Dope','1-415-902-5901','uzi@synpat.com','Hi, I would like to participate in your syndicate, but I do not want anyone know that I\'m doing so. Can you keep that in confidence, what are your confidential arrangements? perhaps I can contact you via a counsel?','https://drive.google.com/file/d/0B-7JHq4pougDbGdPU0pUQmhxd0U/view?usp=drivesdk',0.40,'',0,1,'2015-09-10 21:41:09','2015-09-10 21:49:25'),(19,0,'','','','','','',0.00,'',0,1,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(20,0,'','','','','','',0.00,'',0,1,'0000-00-00 00:00:00','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `potential_participates` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-21 19:39:47
