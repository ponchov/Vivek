-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: q3vtafztappqbpzn.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: uyfpb5wx6tnyzrhm
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backyard_comparables`
--

DROP TABLE IF EXISTS `backyard_comparables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backyard_comparables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lead_id` int(11) NOT NULL,
  `file_name` varchar(300) NOT NULL,
  `file_link` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1876 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backyard_comparables`
--

LOCK TABLES `backyard_comparables` WRITE;
/*!40000 ALTER TABLE `backyard_comparables` DISABLE KEYS */;
INSERT INTO `backyard_comparables` VALUES (597,217,'<b>Wearable device </b><br/>3% of net revenue from product\'s sales <br/>Non-Invasive Monitoring Systems, Inc. / LifeShirt.com, Inc.','http://www.sec.gov/Archives/edgar/data/720762/000111650200500008/0001116502-00-500008-0001.txt'),(598,217,'<b>Wearable device </b><br/>3.5% of net revenue from product\'s sales <br/>NANYANG TECHNOLOGICAL UNIVERSITY / BLUE SPHERE CORPORATION','http://www.sec.gov/Archives/edgar/data/1419582/000114420414065172/v393304_8k.htm'),(599,217,'<b>Wearable device </b><br/>3% of net revenue from product\'s sales <br/>Tubz, LLC / William Marsh Rice University','http://www.getfilings.com/sec-filings/141223/GRAPHITE-CORP_8-K/grph_ex101.htm'),(600,217,'<b>Wearable device </b><br/>10% of the Cost of the Licensed Technology <br/>ORYON TECHNOLOGIES, INC. / MYANT CAPITAL PARTNERS INC.','http://www.sec.gov/Archives/edgar/data/1436164/000114420414072891/v396036_ex10-6.htm'),(601,217,'<b>Power Reduction technology </b><br/>$12,000,000/quarter <br/>Rambus Inc. / SK hynix Inc.','http://sec.edgar-online.com/rambus-inc/10-q-quarterly-report/2015/07/23/section19.aspx'),(602,217,'<b>Emotion analysis by wearable devices </b><br/>30% of Net Sales revenue <br/>EXMOCARE LLC / BT2 INTERNATIONAL, INC.','http://www.sec.gov/Archives/edgar/data/1394779/000135448810000670/exmo_ex103.htm'),(603,217,'<b>Emotion analysis </b><br/>33% of Income before taxes <br/>ENRON CORP. / UBS AG','http://www.sec.gov/Archives/edgar/data/1024401/000090951802000120/0000909518-02-000120.txt'),(604,217,'<b>Power saving chips </b><br/>0.3% of Net sales <br/>Fujitsu Limited/ Spansion Inc.','http://www.sec.gov/Archives/edgar/data/1322705/000119312505246697/dex105.htm'),(614,43,'<b>Royalty rates for LTE</b>','http://lesnouvelles.lesi.org/lesnouvelles2010/lesNouvellesPDF09-10/Royalty_Rates_And_Licensing_Strategies_For_Essential_Patents_On_LTE_4G_Telecommunication_Standards.pdf'),(615,43,'<b>UMTS, 3G</b><br/>$9,500,000 (initial licensing fee)<br/>Interdigital/ Beceem','http://www.sec.gov/Archives/edgar/data/1274991/000119312510075918/dex1012.htm'),(616,43,'<b>WiMax</b><br/>$39,000,000<br/>AT&T/ Vonage','http://www.sec.gov/Archives/edgar/data/1272830/000119312508059036/dex1039.htm'),(617,43,'<b>Wireless Communications</b><br/>$58,000,000<br/>Broadcom/ Emulex','http://www.sec.gov/Archives/edgar/data/350917/000119312512375827/d364701dex1054.htm'),(618,43,'<b>Wireless Communications</b><br/>1.625% of each end product<br/>Lucent/ CAP Acquisition','http://www.sec.gov/Archives/edgar/containers/fix049/1081197/000089161899001414/0000891618-99-001414.txt'),(619,43,'<b>Wireless Communications</b><br/>$50,000 upfront fee + 6% of yearly sales revenue<br/>Unity Wireless/ Paragon Communications','http://www.secinfo.com/d113j2.27r.8.htm#1stPage'),(620,43,'<b>Wireless Communications</b><br/>$4,500,000 (initial licensing fee) + 3% (max) of yearly sales revenue<br/>Motorola/ Wireless Medicine Inc.','http://www.sec.gov/Archives/edgar/containers/fix045/1114105/000095014400013017/g64816ex10-13.txt'),(621,43,'<b>Wireless Communications</b><br/>15% of revenues<br/>Science Applications/ VirnetX Inc.','http://www.sec.gov/Archives/edgar/data/1336920/000119312510073854/dex991.htm'),(1867,127,'<b>LED </b><br/>2.5% of net sales <br/>DA VINCI SYSTEMS/ MILESTONE SCIENTIFIC','http://www.sec.gov/Archives/edgar/containers/fix068/855683/000112528206002245/b412754ex10_10.txt'),(1868,127,'<b>Optoelectronics </b><br/>1.625% of each licensed product <br/>LUCENT TECHNOLOGIES INC./ CAP ACQUISITION CORP.','http://www.sec.gov/Archives/edgar/containers/fix049/1081197/000089161899001414/0000891618-99-001414.txt'),(1869,127,'<b>Optoelectronics </b><br/>2% of sales revenue <br/>INTERSIL CORPORATION/  HARRIS CORPORATION','http://www.sec.gov/Archives/edgar/data/1096325/000088981200003853/0000889812-00-003853-0001.txt'),(1870,127,'<b>LED </b><br/>5% of Product sales <br/>Invention Development Management Company/ Visualant, Inc','http://www.sec.gov/Archives/edgar/data/1074828/000119983514000047/exhibit_10-52.htm'),(1871,127,'<b>Lighting Control </b><br/>0.85% of Net Sales of licensed products <br/>AXIS TECHNOLOGIES, INC./ THE REGENTS OF THE UNIVERSITY OF CALIFORNIA','http://www.sec.gov/Archives/edgar/data/1386262/000114036109009648/form10k.htm'),(1872,127,'<b>Lighting Control </b><br/>2.5% of product\'s net selling price <br/>Logic Laboratories, Inc/ Elgin Technologies Inc.','http://www.sec.gov/Archives/edgar/containers/fix061/1107947/0001005477-00-002036.txt'),(1873,127,'<b>Lighting Control Chips </b><br/>0.3% of Net Sales of Licensed Products <br/>Fujitsu/ Spansion','http://www.sec.gov/Archives/edgar/data/1322705/000119312505187045/dex106.htm'),(1874,127,'<b>Lighting Control Chips </b><br/>0.3% of Net Sales of Licensed Products <br/>AMD/ Spansion','http://www.sec.gov/Archives/edgar/data/1322705/000119312505187045/dex107.htm'),(1875,127,'<b>Control Chips </b><br/>0.5% of Net Sales <br/>Texas Instruments/ Sensata Technologies','http://www.sec.gov/Archives/edgar/data/1381272/000119312506261688/dex1010.htm');
/*!40000 ALTER TABLE `backyard_comparables` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-21 19:28:14
