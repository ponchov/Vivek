-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: q3vtafztappqbpzn.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: uyfpb5wx6tnyzrhm
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `lead_open_project`
--

DROP TABLE IF EXISTS `lead_open_project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lead_open_project` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lead_id` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `contact_id` int(11) DEFAULT '0',
  `password` varchar(15) NOT NULL DEFAULT '12345',
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_open_project`
--

LOCK TABLES `lead_open_project` WRITE;
/*!40000 ALTER TABLE `lead_open_project` DISABLE KEYS */;
INSERT INTO `lead_open_project` VALUES (4,227,3,0,2,'12345'),(5,227,2,0,4353,'12345'),(6,227,4,0,120,'12345'),(9,227,3,0,4357,'12345'),(10,227,3,0,120,'12345'),(11,227,9,1,2,'12345'),(12,227,3,0,198,'12345'),(13,227,9,2,120,'12345'),(14,265,2,1,4353,'12345'),(15,265,10,0,45,'12345'),(16,265,4,0,45,'54321'),(17,265,3,0,198,'12345'),(18,265,3,0,198,'12345'),(19,150,9,1,5395,'12345'),(25,227,6,0,4286,'12345'),(31,150,9,2,5398,'12345'),(32,265,2,1,45,'12345'),(33,150,9,1,45,'12345'),(34,265,11,0,2,'12345'),(35,265,2,0,5396,'12345'),(36,150,9,2,5408,'12345'),(37,150,9,0,5399,'12345'),(38,265,8,0,45,'12345'),(39,265,9,0,45,'12345'),(40,150,2,0,4286,'12345'),(42,354,2,0,45,'12345'),(45,400,4,1,2,'12345'),(53,400,4,1,2,'12345'),(54,400,4,1,45,'12345'),(55,400,4,0,5597,'12345'),(56,400,3,1,45,'12345'),(57,400,3,1,5596,'12345'),(58,400,3,1,4286,'12345'),(59,400,3,0,4286,'12345'),(60,400,2,1,5596,'12345'),(61,400,2,0,4365,'12345'),(62,467,3,1,5596,'12345'),(63,467,3,0,5411,'login@123'),(64,467,2,0,5411,'login@123'),(65,467,4,0,5411,'12345');
/*!40000 ALTER TABLE `lead_open_project` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-21 19:25:35
