-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: q3vtafztappqbpzn.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: uyfpb5wx6tnyzrhm
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `password` varchar(60) NOT NULL,
  `type` tinyint(4) NOT NULL DEFAULT '1',
  `profile_pic` varchar(500) NOT NULL DEFAULT '',
  `forgot_code` varchar(200) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `flag` int(11) NOT NULL DEFAULT '1',
  `send_email` int(11) NOT NULL DEFAULT '0',
  `user_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Creation date',
  `user_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_last_login` datetime DEFAULT NULL,
  `ext` varchar(45) DEFAULT '102',
  `title` varchar(100) DEFAULT NULL,
  `direct_number` varchar(45) DEFAULT NULL,
  `mobile_number` varchar(45) DEFAULT NULL,
  `email_for_signature` varchar(255) DEFAULT '',
  `google_token` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Vivek Kapoor','webmaster@synpat.com','+919478793552','$2a$08$SK4vdq5erQ71r8Ui7hnVyuQZ0hVslZkCHzAaBPRHlrJES7QJfY3hq',9,'https://knzbeoknwf.s3.amazonaws.com/public/upload/profile.jpg','',0,1,0,'2014-12-08 11:37:02','2016-09-20 20:27:04','2016-11-21 18:09:27','102','Web Developer','+1-415-649-6378','+919478793552','webmaster@synpat.com','{\"access_token\":\"ya29.Ci-eA8UsJAdieVJYxJDckIkqYal_yWAQb7HLmN7cYekdFJ5B3kKLi0eaVpkVgsZoKg\",\"expires_in\":3600,\"id_token\":\"eyJhbGciOiJSUzI1NiIsImtpZCI6IjM4Y2FjZjM3ZjUyOWQ4YzM2ZDBlNmJkYzU5OTNlNWQ3Njk1ZDg5NzgifQ.eyJpc3MiOiJhY2NvdW50cy5nb29nbGUuY29tIiwiaWF0IjoxNDc5NzgwNTk4LCJleHAiOjE0Nzk3ODQxOTgsImF0X2hhc2giOiJCbVdvb3dvcUpKZFVqQ191MHJsdTJnIiwiYXVkIjoiMTAzNjI4NTUzNzY3My1sOGdhazF1bjdhMThxbDZicTlzM2k2dWFnNXVtaXQ3Yi5hcHBzLmdvb2dsZXVzZXJjb250ZW50LmNvbSIsInN1YiI6IjEwNzEzOTY2NTE0MjgyMDY3NDE2MCIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJhenAiOiIxMDM2Mjg1NTM3NjczLWw4Z2FrMXVuN2ExOHFsNmJxOXMzaTZ1YWc1dW1pdDdiLmFwcHMuZ29vZ2xldXNlcmNvbnRlbnQuY29tIiwiaGQiOiJzeW5wYXQuY29tIiwiZW1haWwiOiJ3ZWJtYXN0ZXJAc3lucGF0LmNvbSJ9.VcMtzfKr-QMb0-LuszMF6Grq_p_0KLRxIt_QDcABHXhDSVN4Qny5YBJ_6p5qJLkqKfYRZTXsEzOfSxgyVaYzDlz_h5Y4Z0Xp9pa0K44vY3RWtuQUdnKikTuGoQTSVru1NlfFZ71Rp9--OAOy2EVzsmbJgCD5Octfg_ngqf3UsSos_NvI6qllTXSJS2rlovWuTDLO0PGoYMqai5Z7qr_xgI6UlXzSX4UxEJzKsHVGAiRTOPVE2Np9zUd4xIrDao32jFEC4Et7Tpn8Q9tUwlKtdBqqyyKJ2DUYXKf_NK5K93QFywjIbjnqmWEH3k6jPBIoGyBSTA9LRkzggTUMbHGWwg\",\"refresh_token\":\"1\\/Ap--nEjK83pjDmQbTEgbM9DPuvHvUxSOY3jiA-SdrtQ\",\"token_type\":\"Bearer\",\"created\":1479780598}'),(10,'Uzi Aloush','uzi@synpat.com','+1-415-805-8813','$2a$08$d4ZQlYSF5jfba5CVd8y0CewSKGitFVQwn76ovsTmPzgsiUTacA2bK',9,'https://knzbeoknwf.s3.amazonaws.com/public/upload/UziAloush.jpg','',0,1,0,'2014-12-08 11:37:02','2016-10-20 12:48:45','2016-11-21 14:05:27','101','CEO','1-415-805-8813','','','{\"access_token\":\"ya29.Ci-dA2FJrExnLTaNs5FgHsL_5V8M00NC_SxFg154hVrCskiO8Mm63702VUlJpT29XA\",\"expires_in\":3600,\"id_token\":\"eyJhbGciOiJSUzI1NiIsImtpZCI6IjM4Y2FjZjM3ZjUyOWQ4YzM2ZDBlNmJkYzU5OTNlNWQ3Njk1ZDg5NzgifQ.eyJpc3MiOiJhY2NvdW50cy5nb29nbGUuY29tIiwiaWF0IjoxNDc5NzY2MDI0LCJleHAiOjE0Nzk3Njk2MjQsImF0X2hhc2giOiJvWnVvbl9FaXFUNjlUWXcwb1F3d093IiwiYXVkIjoiMTAzNjI4NTUzNzY3My1sOGdhazF1bjdhMThxbDZicTlzM2k2dWFnNXVtaXQ3Yi5hcHBzLmdvb2dsZXVzZXJjb250ZW50LmNvbSIsInN1YiI6IjExNzMyMTE5MjM2MDUxODU0NDI0MCIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJhenAiOiIxMDM2Mjg1NTM3NjczLWw4Z2FrMXVuN2ExOHFsNmJxOXMzaTZ1YWc1dW1pdDdiLmFwcHMuZ29vZ2xldXNlcmNvbnRlbnQuY29tIiwiaGQiOiJzeW5wYXQuY29tIiwiZW1haWwiOiJ1emlAc3lucGF0LmNvbSJ9.tKoWcKwgat43Xjz7vpibevsFt1xxrmaBOginaVfiGYvgOfD_fY4f3fGz9pSMj1XEf9dE4z-ZFZDgvLVj3-pum0PdQRhZRuEf_BVYkYpYtTFsbDzoaPhUzvB6hVsSea9pgY4owBEhPbucngZQuYc9RFiULU3RiVr7YeuvX9rHspQ6lARwe8K1dzsrQ6f_z_nn2rzgdnkw9hDrp_zt28UqMjm4Sc8Ck44nmQimIK-5m0wTUpTcvRLiBcAUoHLBO2f3dsH0FYN4jJo9G95nSWVXqUycVG7xkjJzJg7eNVcC03RPvPA5EV1uwqZtS9HvmKeNuu7HqCifWsN3mw1nXXQj5A\",\"refresh_token\":\"1\\/Pp2I9NqkBel28XAhuGMruIWczVvsZXCS0InKl9o9yqA\",\"token_type\":\"Bearer\",\"created\":1479766024}'),(11,'Sanjay','sanjay@synpat.com','','$2a$08$L/LlD3LECShEWmGnWW7pge8fctOjkyOdksUAs7yrMn.LbOXYkIb2m',8,'','',0,1,0,'2014-12-08 11:37:02','2015-05-14 09:45:10','2016-04-12 17:29:52','102',NULL,NULL,NULL,'',''),(12,'Kerry','kerry@synpat.com','','$2a$08$d4ZQlYSF5jfba5CVd8y0CewSKGitFVQwn76ovsTmPzgsiUTacA2bK',8,'','df74db20d816f8262d85b64dcf0fd6ce',1,1,0,'2015-03-02 08:26:47','2015-03-02 08:26:47','2015-10-21 00:11:02','102',NULL,NULL,NULL,'',''),(13,'Designer Dummy','dymmyadsynpat@gmail.com','','$2a$08$d4ZQlYSF5jfba5CVd8y0CewSKGitFVQwn76ovsTmPzgsiUTacA2bK',1,'','',0,1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','2016-03-03 21:54:21','102',NULL,NULL,NULL,'',''),(14,'Matt Cohen','mcohen@ifvisions.com','(415) 225-3365','$2a$08$TgDKWVA9KnVioUg0LXnP5OgvZjR92PzYOI9nHBUp0ueb4bC3hne7i',1,'','',1,0,0,'2015-04-01 12:00:43','2015-04-01 12:00:43','2015-04-01 13:51:23','102',NULL,NULL,NULL,'',''),(15,'SynPat','synpat@synpat.com','1234567890','$2a$08$cqq7aW31qk77fWWHCQi49.1hE/UYGs.0eHAT7.oZqgF/ifGs.b1re',9,'','',0,1,0,'2015-04-14 01:21:46','2015-04-14 01:21:46','2015-06-02 21:11:37','102',NULL,NULL,NULL,'',''),(16,'Ron Laurie','ron@synpat.com','6508145600','$2a$08$.PZCHDk5I/SHG5ZZ92EUyOn2hYKZio1iu4oPV3pSK/AICCC2yAo8.',1,'','',0,1,0,'2015-05-21 10:41:36','2015-05-21 10:41:36',NULL,'102',NULL,NULL,NULL,'',''),(17,'Satish Rana','satish@synpat.com','','$2a$08$d4ZQlYSF5jfba5CVd8y0CewSKGitFVQwn76ovsTmPzgsiUTacA2bK',1,'https://knzbeoknwf.s3.amazonaws.com/public/upload/DSCN3320.JPG','',1,1,0,'0000-00-00 00:00:00','2015-09-24 13:34:19','2015-11-11 22:20:33','102',NULL,NULL,NULL,'',''),(18,'Amy Lund','lund.amy@gmail.com','+1-415-649-6378','$2a$08$d4ZQlYSF5jfba5CVd8y0CewSKGitFVQwn76ovsTmPzgsiUTacA2bK',1,'','',0,1,1,'2015-10-14 17:40:16','2015-10-14 17:40:16','2016-10-04 11:23:44','102',NULL,NULL,NULL,'','{\"access_token\":\"ya29.Ci9rA5EFCY4WuZL3pd4dJZB6gpbto8esHXGnPiuY9KqCEzI1R68Eg2fe7TKgxCs3aQ\",\"token_type\":\"Bearer\",\"expires_in\":3600,\"id_token\":\"eyJhbGciOiJSUzI1NiIsImtpZCI6IjAzYzFjMGRiNzM2Y2ZkMTMxNDFhY2QxOGQ4ZGNiMzM2MGFhNDU5MDkifQ.eyJpc3MiOiJhY2NvdW50cy5nb29nbGUuY29tIiwiYXRfaGFzaCI6InVTMVM0TThWbnMyQzY1c01RM25OUWciLCJhdWQiOiIxMDM2Mjg1NTM3NjczLWw4Z2FrMXVuN2ExOHFsNmJxOXMzaTZ1YWc1dW1pdDdiLmFwcHMuZ29vZ2xldXNlcmNvbnRlbnQuY29tIiwic3ViIjoiMTA3MTM5NjY1MTQyODIwNjc0MTYwIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImF6cCI6IjEwMzYyODU1Mzc2NzMtbDhnYWsxdW43YTE4cWw2YnE5czNpNnVhZzV1bWl0N2IuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJoZCI6InN5bnBhdC5jb20iLCJlbWFpbCI6IndlYm1hc3RlckBzeW5wYXQuY29tIiwiaWF0IjoxNDc1MDg4NDczLCJleHAiOjE0NzUwOTIwNzN9.REv1fGEZ_7ULCKrdKX9xpRRc-SzgWGPK1y4rHtRQXHwkIY93ORb9C4kcqgP0u47SeOpsalu58vJ7mDWyw8E_ssZ4-v6AmZiM3Cl6bXT6mArCvA43o0aoNEusp-3uWijMUg5JSIBBfSJrUWUKnl3ZPBA_0nbN_Zrl60IjSz3M09-SMxlQoJRYQvj0sCuJep6qHpiV1Ad9DB9GOhkm9gxqR0ZhpL1gexQde6_CmU7-9Vzua40u6rY0SPFGiG1oQS6YHKxl6w2tvyIx2SIkkL82YP2iS0NMdH45g1UTS2Zn0IcF1Sjt-oGPTquf72v8_RPz8sTy4s6WlqG77SMokudtsQ\",\"refresh_token\":\"1\\/bfHxEFe1pBCZAd5KjqCB8y2zHcMm0pqX9DRmFMOV1v8\",\"created\":1475088473}'),(19,'Michele Moreland','michele@morelandip.com','','$2a$08$d4ZQlYSF5jfba5CVd8y0CewSKGitFVQwn76ovsTmPzgsiUTacA2bK',8,'','',0,0,0,'2015-12-05 21:22:09','2015-12-05 21:22:09','2016-01-04 14:25:50','102',NULL,NULL,NULL,'',''),(20,'Tina Leong','tina@tinaleong.com','9255504932','$2a$08$oybL2czkglQGRP6FIyNr/eiISrxCBre8CcbYW923aQI5oxJhOyIie',1,'','',0,1,0,'2016-01-06 15:24:12','2016-01-06 15:24:12',NULL,'102',NULL,NULL,NULL,'',''),(21,'Aaron Waxler','aaron.waxler@nxp.com','+1-415-649-6378','$2a$08$d4ZQlYSF5jfba5CVd8y0CewSKGitFVQwn76ovsTmPzgsiUTacA2bK',1,'','',0,1,1,'2015-10-14 17:40:16','2015-10-14 17:40:16','2016-01-27 10:18:25','102',NULL,NULL,NULL,'',''),(22,'David A','david@synpat.com','4158584700','$2a$08$NJy4FWsFgwe6SvRzdHxJTeYW4/Xm9wuncQDJ6tSMH8OEm0lbL4nPq',8,'https://knzbeoknwf.s3.amazonaws.com/public/upload/80x80.png','',0,1,0,'2016-01-27 08:47:10','2016-02-05 11:18:11','2016-02-08 15:55:16','102',NULL,NULL,NULL,'',''),(23,'James Antonino','jdantonino1@gmail.com','6038688999','$2a$08$d4ZQlYSF5jfba5CVd8y0CewSKGitFVQwn76ovsTmPzgsiUTacA2bK',1,'https://knzbeoknwf.s3.amazonaws.com/public/upload/301edca.jpg','',1,0,0,'2016-02-18 13:37:50','2016-02-19 11:09:35','2016-05-03 00:05:26','102','Sales Development','603-868-8999','603-860-7759','licenses@synpat.com',''),(24,'Rahul','er.vivek2512@gmail.com','+1-415-568-7517','$2a$08$d4ZQlYSF5jfba5CVd8y0CewSKGitFVQwn76ovsTmPzgsiUTacA2bK',1,'https://knzbeoknwf.s3.amazonaws.com/public/upload/profile.jpg','',0,0,0,'2016-03-03 21:48:09','2016-03-06 00:34:53','2016-03-17 13:40:01','102','Sales Development','+1-415-649-6378','+1-415-568-7517','licenses@synpat.com',''),(25,'Neha Salgotra','neha.salgotra12@winsomeip.com','+91 9888360212','12345',1,'','',1,0,0,'2016-03-30 21:21:37','2016-03-31 03:47:30','2016-04-06 23:57:23','102','Director of Operations','+91 9888360212','+91 9888360212','patents@synpat.com',''),(26,'Anuradha B','dhanura@gmail.com','','$2a$08$gpcCrQtpTHnjLuSt9k1F6eH4iCncNusQK0QymBvGojZOkqD/QhRF.',8,'','',0,1,0,'2016-08-18 11:00:59','2016-08-18 11:00:59','2016-10-11 08:01:08','','','',NULL,'',''),(27,'Bhaskar Pandey','bhaskar.patent@gmail.com','+91-11- 4183 55','$2a$08$cA5K2Lj6htVyOyDRMKENC.0GU0l1S7Ez9NeF0o3nYLUwD8W6KyaRS',1,'','',0,0,0,'2016-10-05 20:56:45','2016-10-05 20:59:48','2016-10-20 10:28:57','','Acquisitions Manager','0',NULL,NULL,'');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-21 19:40:58
