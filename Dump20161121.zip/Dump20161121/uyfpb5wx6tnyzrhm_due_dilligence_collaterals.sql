-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: q3vtafztappqbpzn.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: uyfpb5wx6tnyzrhm
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `due_dilligence_collaterals`
--

DROP TABLE IF EXISTS `due_dilligence_collaterals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `due_dilligence_collaterals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patent_id` varchar(30) NOT NULL,
  `creditor_name` varchar(400) NOT NULL,
  `date_for_aggreement` varchar(50) NOT NULL,
  `expirtation_date` varchar(50) NOT NULL,
  `terminated_file` varchar(500) NOT NULL,
  `comment` text NOT NULL,
  `knowledge` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=137 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `due_dilligence_collaterals`
--

LOCK TABLES `due_dilligence_collaterals` WRITE;
/*!40000 ALTER TABLE `due_dilligence_collaterals` DISABLE KEYS */;
INSERT INTO `due_dilligence_collaterals` VALUES (1,'US6845097','Creditor\'s Name0','2014-03-02 00:00:00','2014-03-18 00:00:00','2076523156_1395211305Screenshot from 2013-11-27 18:02:21.png','The financing statement associated with the security interest were filed with the appropriate offices of the state of 0 ',0),(2,'US6909878','','1969-12-31 00:00:00','1969-12-31 00:00:00','2076523156_1395211305Screenshot from 2013-11-27 18:02:21.png','',0),(3,'US6957045','','0000-00-00 00:00:00','0000-00-00 00:00:00','2076523156_1395211305Screenshot from 2013-11-27 18:02:21.png','',0),(4,'US7013112','','0000-00-00 00:00:00','0000-00-00 00:00:00','2076523156_1395211305Screenshot from 2013-11-27 18:02:21.png','',0),(5,'US7016334','','0000-00-00 00:00:00','0000-00-00 00:00:00','2076523156_1395211305Screenshot from 2013-11-27 18:02:21.png','',0),(6,'US5379764','Daniel Amstrong','2004-11-02 00:00:00','2022-11-23 00:00:00','','This can also be applied to monitoring and controlling ecological pollution, including industrial waste waters and for monitoring and controlling industrial processes in general.',0),(7,'US5360004','','0000-00-00 00:00:00','0000-00-00 00:00:00','','',0),(8,'US5460177','','0000-00-00 00:00:00','0000-00-00 00:00:00','','',0),(9,'US6283831','','0000-00-00 00:00:00','0000-00-00 00:00:00','','',1),(10,'US6776588','','0000-00-00 00:00:00','0000-00-00 00:00:00','','',1),(11,'US7653456','','0000-00-00 00:00:00','0000-00-00 00:00:00','','',1),(12,'US6547651','','0000-00-00 00:00:00','0000-00-00 00:00:00','','',1),(13,'US6283831','','0000-00-00 00:00:00','0000-00-00 00:00:00','','',1),(14,'US6776588','','0000-00-00 00:00:00','0000-00-00 00:00:00','','',1),(15,'US7653456','','0000-00-00 00:00:00','0000-00-00 00:00:00','','',1),(16,'US6547651','','0000-00-00 00:00:00','0000-00-00 00:00:00','','',1),(17,'US6789876','','0000-00-00 00:00:00','0000-00-00 00:00:00','','',1),(18,'US6790431','','0000-00-00 00:00:00','0000-00-00 00:00:00','','',1),(19,'US6787874','','0000-00-00 00:00:00','0000-00-00 00:00:00','','',1),(20,'US8338331','','1969-12-31 18:00:00','1969-12-31 18:00:00','','',0),(21,'US8338339','','1969-12-31 18:00:00','1969-12-31 18:00:00','','',0),(22,'US8338340','','0000-00-00 00:00:00','0000-00-00 00:00:00','','',0),(23,'US8338341','','1969-12-31 18:00:00','1969-12-31 18:00:00','','',0),(24,'US8338342','','1969-12-31 18:00:00','1969-12-31 18:00:00','','',0),(25,'US8338343','','1969-12-31 18:00:00','1969-12-31 18:00:00','','',0),(98,'US7557524','','1969-12-31 18:00:00','1969-12-31 18:00:00','','',0),(108,'US8909824','','1969-12-31 18:00:00','1969-12-31 18:00:00','','',0),(109,'US8386667','','1969-12-31 18:00:00','1969-12-31 18:00:00','','',0),(110,'US9110563B2','','1970-01-01 00:00:00','1970-01-01 00:00:00','','',0),(111,'US8902225B2','','1970-01-01 00:00:00','1970-01-01 00:00:00','','',0),(112,'US8730165B2','','1970-01-01 00:00:00','1970-01-01 00:00:00','','',0),(113,'US8477098B2','','1970-01-01 00:00:00','1970-01-01 00:00:00','','',0),(114,'US8319773B2','','1970-01-01 00:00:00','1970-01-01 00:00:00','','',0),(115,'14/794,080','','1970-01-01 00:00:00','1970-01-01 00:00:00','','',0),(127,'US7076037B1','','0000-00-00 00:00:00','0000-00-00 00:00:00','','',0),(128,'US7953416B2','','0000-00-00 00:00:00','0000-00-00 00:00:00','','',0),(129,'US8200231B2','','0000-00-00 00:00:00','0000-00-00 00:00:00','','',0),(130,'US20070269038A1','','0000-00-00 00:00:00','0000-00-00 00:00:00','','',0),(131,'AU2005319281','','0000-00-00 00:00:00','0000-00-00 00:00:00','','',0),(132,'JP4774058B2','','0000-00-00 00:00:00','0000-00-00 00:00:00','','',0),(133,'Expired:','','0000-00-00 00:00:00','0000-00-00 00:00:00','','',0),(134,'WO2008008993','','0000-00-00 00:00:00','0000-00-00 00:00:00','','',0),(135,'AU2007272342','','0000-00-00 00:00:00','0000-00-00 00:00:00','','',0),(136,'CA2650115A1','','0000-00-00 00:00:00','0000-00-00 00:00:00','','',0);
/*!40000 ALTER TABLE `due_dilligence_collaterals` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-21 19:43:22
