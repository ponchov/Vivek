-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: q3vtafztappqbpzn.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: uyfpb5wx6tnyzrhm
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `store_users`
--

DROP TABLE IF EXISTS `store_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `store_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `access_code` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `project_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=162 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `store_users`
--

LOCK TABLES `store_users` WRITE;
/*!40000 ALTER TABLE `store_users` DISABLE KEYS */;
INSERT INTO `store_users` VALUES (1,'1qa2ws3ed','admin',0),(2,'qawsed','user',6),(101,'12345','user',112),(102,'12345','user',113),(103,'12345','user',114),(104,'12345','user',115),(105,'12345','user',116),(106,'12345','user',117),(107,'12345','user',118),(108,'12345','user',119),(109,'12345','user',120),(110,'12345','user',121),(111,'12345','user',122),(112,'12345','user',123),(113,'12345','user',124),(114,'12345','user',125),(115,'12345','user',126),(116,'12345','user',127),(117,'12345','user',128),(118,'12345','user',129),(119,'12345','user',130),(120,'12345','user',131),(121,'12345','user',132),(122,'12345','user',133),(123,'12345','user',134),(124,'12345','user',135),(125,'12345','user',136),(126,'12345','user',137),(127,'12345','user',138),(128,'12345','user',139),(129,'12345','user',140),(130,'12345','user',141),(131,'12345','user',142),(132,'12345','user',143),(133,'12345','user',144),(134,'12345','user',145),(135,'12345','user',146),(136,'12345','user',147),(137,'12345','user',148),(138,'12345','user',149),(139,'12345','user',150),(140,'12345','user',151),(141,'12345','user',152),(142,'12345','user',153),(143,'12345','user',154),(144,'12345','user',155),(145,'12345','user',156),(146,'12345','user',160),(147,'12345','user',161),(148,'12345','user',162),(149,'12345','user',163),(150,'12345','user',165),(151,'12345','user',166),(152,'12345','user',167),(153,'12345','user',168),(154,'12345','user',169),(155,'12345','user',170),(156,'12345','user',171),(157,'12345','user',172),(158,'12345','user',173),(159,'12345','user',174),(160,'12345','user',175),(161,'12345','user',176);
/*!40000 ALTER TABLE `store_users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-21 19:37:17
