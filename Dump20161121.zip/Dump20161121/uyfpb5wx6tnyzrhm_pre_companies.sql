-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: q3vtafztappqbpzn.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: uyfpb5wx6tnyzrhm
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pre_companies`
--

DROP TABLE IF EXISTS `pre_companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pre_companies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(300) NOT NULL,
  `company_address` varchar(500) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `postal_code` varchar(40) NOT NULL,
  `country` varchar(100) NOT NULL,
  `web_address` varchar(500) NOT NULL,
  `linkedin_url` varchar(255) NOT NULL,
  `email` varchar(500) NOT NULL,
  `telephone` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=110 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pre_companies`
--

LOCK TABLES `pre_companies` WRITE;
/*!40000 ALTER TABLE `pre_companies` DISABLE KEYS */;
INSERT INTO `pre_companies` VALUES (27,'360BRANDVISION','','','','','','','','',''),(28,'4Dpresence ','','','','','','','SAP Helix Project','',''),(29,'AV Concepts','','','','','','','Holoxica Third Generation','',''),(30,'Avegant','','','','','','','','',''),(35,'Christie Digital','','','','','','','Christie Digital','',''),(37,'Cyberglove Systems','','','','','','','','',''),(41,'echoPixel ','','','','','','','HoloCube','',''),(42,'EON Reality','','','','','','','Holoxica Second Generation','',''),(45,'Geomagic ','','','','','','','','',''),(46,'H+ Tech','','','','','','','H+ Tech HoloMax','',''),(47,'HoloCube ','','','','','','','Intel Touch Sensitive Hologram Display','',''),(48,'HologamUSA ','','','','','','','ImmersiveTouch Simulators','',''),(49,'Holovect Industries ','','','','','','','HP Sprout','',''),(50,'Holoxica ','','','','','','','Holovect Volumetric Display','',''),(52,'HumanEyes','','','','','','','','',''),(53,'ImmersiveTouch ','','','','','','','Leia 3D Technology','',''),(55,'Leap Motion','','','','','','','','',''),(56,'Leia3D ','','','','','','','Provision TV','',''),(58,'Lincoln Global','','','','','','','','',''),(62,'Musion ','','','','','','','EON Holographics','',''),(63,'Navdy ','','','','','','','','',''),(64,'Nettlebox ','','','','','','','NettleBox','',''),(65,'NextCore','','','','','','','','',''),(68,'Occipital ','','','','','','','Philips and Real View','',''),(72,'Provision','','','','','','','RealView Imaging','',''),(74,'RealView - Medical Holography  ','','','','','','','Voxiebox','',''),(76,'SEGA ','','','','','','','SEGA Holographic Game','',''),(77,'Sensics','','','','','','','','',''),(78,'Serious Simulations','','','','','','','','',''),(79,'Sixense','','','','','','','','',''),(82,'SpaceX ','','','','','','','','',''),(83,'Sulon Cortex','','','','','','','','',''),(84,'Takee','','','','','','','Google Holograms','',''),(87,'ViewSonic ','','','','','','','','',''),(88,'Virdex','','','','','','','SONY Holographic Television','',''),(89,'Volkswagen','','','','','','','SONY 3D Display','',''),(90,'Voxiebox ','','','','','','','Voxiebox Worlds First Holographic Gaming System','',''),(92,'Zebra Imaging ','','','','','','','','',''),(93,'ZSpace Inc ','','','','','','','ZSpace','',''),(94,'Beenoculus','','','','','','','','',''),(95,'celluon','','','','','','','','',''),(96,'Magic Leap','','','','','','','Magic Leap','',''),(97,'Oculus (Parent: Facebook)','','','','','','','Oculus Rift','',''),(98,'Apple','','','','','','','Hologram USA 3D Light Box','',''),(99,'Intel','','','','','','','Occipital','',''),(100,'Zebra','','','','','','','Zebra Imaging','',''),(101,'Imaging','','','','','','','Zebra Imaging - Motion Displays','',''),(102,'CISCO','','','','','','','CISCO Telepresence','',''),(103,'HP','','','','','','','HP Specialty Z Displays','',''),(104,'Disney','','','','','','','Disney - Rapid Hologram Generation','',''),(105,'Ninendo','','','','','','','Nintendo Hologram','',''),(106,'Samsung','','','','','','','Samsung VR','',''),(107,'SONY','','','','','','','SONY Smart Eye Glass','',''),(108,'GE','','','','','','','Volkswagen New Holographic Dashboard GPS Navigator','',''),(109,'Motorola','','','','','','','Nokia Holographic Phone','','');
/*!40000 ALTER TABLE `pre_companies` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-21 19:30:44
