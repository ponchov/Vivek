-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: q3vtafztappqbpzn.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: uyfpb5wx6tnyzrhm
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `due_dilligence_parties`
--

DROP TABLE IF EXISTS `due_dilligence_parties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `due_dilligence_parties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patent_id` varchar(30) NOT NULL,
  `invloved_third_party` varchar(400) NOT NULL,
  `date_of_aggreement` varchar(50) NOT NULL,
  `comment` text NOT NULL,
  `party` varchar(400) NOT NULL,
  `knowledge` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `due_dilligence_parties`
--

LOCK TABLES `due_dilligence_parties` WRITE;
/*!40000 ALTER TABLE `due_dilligence_parties` DISABLE KEYS */;
INSERT INTO `due_dilligence_parties` VALUES (1,'US6845097','Involved third part0','2014-03-19 00:00:00','Please describe your procedures (if any) to keep research and development of the subject patented inventions separate from any projects funded by this third party0','1373556153_1395211305Screenshot from 2014-03-10 18:29:20.png',0),(2,'US6909878','','0000-00-00 00:00:00','','1373556153_1395211305Screenshot from 2014-03-10 18:29:20.png',0),(3,'US6957045','','0000-00-00 00:00:00','','1373556153_1395211305Screenshot from 2014-03-10 18:29:20.png',0),(4,'US7013112','','0000-00-00 00:00:00','','1373556153_1395211305Screenshot from 2014-03-10 18:29:20.png',0),(5,'US7016334','','0000-00-00 00:00:00','','1373556153_1395211305Screenshot from 2014-03-10 18:29:20.png',0),(6,'US6909878','','0000-00-00 00:00:00','','',0),(7,'US5379764','Third Party ','2014-11-18 00:00:00','A method and instrument for determining the amounts of metabolic products in blood using a laser beam guided through an ATR plate placed against a blood supplied biological tissue. The intensity of the beam is then detected after being affected by the blood containing the metabolic elements and is used to determine the amounts of metabolic products in the blood.','',0),(8,'US5360004','','0000-00-00 00:00:00','','',0),(17,'US6283831','Microsoft','2014-12-16 00:00:00','','',0),(18,'US6776588','','0000-00-00 00:00:00','','',0),(19,'US7653456','','0000-00-00 00:00:00','','',0),(20,'US6547651','','0000-00-00 00:00:00','','',0),(33,'US8338331','','1969-12-31 18:00:00','','',0),(34,'US8338339','','1969-12-31 18:00:00','','',0),(35,'US8338340','','0000-00-00 00:00:00','','',0),(36,'US8338341','','1969-12-31 18:00:00','','',0),(37,'US8338342','','1969-12-31 18:00:00','','',0),(38,'US8338343','','1969-12-31 18:00:00','','',0),(39,'US7557524','','1969-12-31 18:00:00','','',0),(40,'US8909824','','1969-12-31 18:00:00','','',0),(41,'US8386667','','1969-12-31 18:00:00','','',0),(42,'US9110563B2','','1970-01-01 00:00:00','','',0),(43,'US8902225B2','','1970-01-01 00:00:00','','',0),(44,'US8730165B2','','1970-01-01 00:00:00','','',0),(45,'US8477098B2','','1970-01-01 00:00:00','','',0),(46,'US8319773B2','','1970-01-01 00:00:00','','',0),(47,'14/794,080','','1970-01-01 00:00:00','','',0),(52,'US7076037B1','','1969-12-31 18:00:00','','',0),(53,'US7953416B2','','0000-00-00 00:00:00','','',0),(54,'US8200231B2','','0000-00-00 00:00:00','','',0),(55,'US20070269038A1','','0000-00-00 00:00:00','','',0),(56,'AU2005319281','','0000-00-00 00:00:00','','',0),(57,'JP4774058B2','','0000-00-00 00:00:00','','',0),(58,'WO2008008993','','0000-00-00 00:00:00','','',0),(59,'AU2007272342','','0000-00-00 00:00:00','','',0),(60,'CA2650115A1','','1969-12-31 18:00:00','','',0);
/*!40000 ALTER TABLE `due_dilligence_parties` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-21 19:38:52
