-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: q3vtafztappqbpzn.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: uyfpb5wx6tnyzrhm
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `potential_syndicates`
--

DROP TABLE IF EXISTS `potential_syndicates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `potential_syndicates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `license_id` int(11) NOT NULL,
  `participate` varchar(50) NOT NULL,
  `fees` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2940 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `potential_syndicates`
--

LOCK TABLES `potential_syndicates` WRITE;
/*!40000 ALTER TABLE `potential_syndicates` DISABLE KEYS */;
INSERT INTO `potential_syndicates` VALUES (97,1,'1','6'),(98,1,'2','3'),(99,1,'3','2'),(100,1,'4','1.5'),(101,1,'5','1.2'),(102,1,'6','1'),(415,3,'1','6'),(416,3,'2','3'),(417,3,'3','2'),(418,3,'4','1.5'),(419,3,'5','1.2'),(420,3,'6','1'),(616,7,'1','6'),(617,7,'2','4.5'),(618,7,'3','3'),(619,7,'2','1.5'),(620,7,'1','1'),(837,44,'1','6'),(838,44,'2','3'),(839,44,'3','2'),(840,44,'4','1.5'),(841,44,'5','1.2'),(842,44,'6','1'),(843,44,'7','0.857'),(844,44,'8','0.75'),(861,46,'1','6'),(862,46,'2','3'),(863,46,'3','2'),(864,46,'4','1.5'),(865,46,'5','1.2'),(866,46,'6','1'),(867,46,'7','0.857'),(868,46,'8','0.75'),(869,82,'1','6'),(870,82,'2','3'),(871,82,'3','2'),(872,82,'4','1.5'),(873,82,'5','1.2'),(874,82,'6','1'),(875,82,'7','0.857'),(876,82,'8','0.75'),(877,82,'1','6'),(878,82,'2','3'),(879,82,'3','2'),(880,82,'4','1.5'),(881,82,'5','1.2'),(882,82,'6','1'),(883,82,'7','0.857'),(884,82,'8','0.75'),(885,82,'1','6'),(886,82,'2','3'),(887,82,'3','2'),(888,82,'4','1.5'),(889,82,'5','1.2'),(890,82,'6','1'),(891,82,'7','0.857'),(892,82,'8','0.75'),(901,6,'1','6'),(902,6,'2','3'),(903,6,'3','2'),(904,6,'4','1.5'),(905,6,'5','1.2'),(906,6,'6','1'),(907,6,'7','0.857'),(908,6,'8','0.75'),(1059,126,'1','6'),(1060,126,'2','3'),(1061,126,'3','2'),(1062,126,'4','1.5'),(1063,126,'5','1.2'),(1064,126,'6','1'),(1089,127,'1','6.0'),(1090,127,'2','3.0'),(1091,127,'3','2.0'),(1092,127,'4','1.5'),(1093,127,'5','1.2'),(1094,127,'6','1.0'),(2744,156,'1','0.6'),(2745,156,'2','0.3'),(2746,156,'3','0.2'),(2747,156,'4','0.15'),(2748,156,'5','0.12'),(2749,156,'6','0.1'),(2750,156,'7','0.087'),(2751,156,'8','0.075'),(2752,156,'9','0.07'),(2753,156,'10','0.06'),(2866,118,'1','0.6'),(2867,118,'2','0.3'),(2868,118,'3','0.2'),(2869,118,'4','0.15'),(2870,118,'5','0.12'),(2871,118,'6','0.1'),(2902,153,'1','1'),(2903,153,'2','0.5'),(2904,153,'3','0.33'),(2905,153,'4','0.25'),(2906,153,'5','0.2'),(2907,153,'6','0.166'),(2908,153,'7','0.142'),(2909,153,'8','0.125'),(2934,124,'1','0.6'),(2935,124,'2','0.3'),(2936,124,'3','0.2'),(2937,124,'4','0.15'),(2938,124,'5','0.12'),(2939,124,'6','0.1');
/*!40000 ALTER TABLE `potential_syndicates` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-21 19:32:05
