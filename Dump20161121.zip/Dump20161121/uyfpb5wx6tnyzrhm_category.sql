-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: q3vtafztappqbpzn.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: uyfpb5wx6tnyzrhm
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `parent` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `explanation` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'Medical',0,0,''),(2,'Software',0,0,''),(3,'Financial Services',0,0,''),(4,'Semiconductors',0,0,''),(5,'E-commerce',0,0,''),(6,'Consumer Electronics',0,0,''),(7,'Mobile Communications',0,0,''),(8,'Automotive',0,0,''),(9,'Networking',0,0,''),(10,'Consumer Products',0,0,''),(11,'Logistics',0,0,''),(12,'Media & Distribution',0,0,''),(13,'Instruments for diagnostic',1,1,'Instruments diagnostic changing and then take to the dssads adsa d  sf sfsd  and to and pack to'),(14,'Surgical and person-identification purposes',1,1,''),(15,'Speech Signal Processing',2,1,'When a user interacts with the holographic image, the sensors sense the user interaction based on quadrilateral angle navigation. The information corresponding to the user interaction is provided to the processor '),(16,'Audio Compression/ Decompression',2,1,''),(17,'Database and file management',2,1,''),(18,'Artificial intelligence',2,1,''),(20,'Use of funds and securities',3,1,''),(21,'Extension of credit',3,1,''),(22,'Portfolio selection',3,1,''),(23,'Insurance',3,1,''),(24,'Audio/radio',4,1,''),(25,'Bipolar transistors',4,1,''),(26,'Data converters',4,1,''),(27,'Diodes',4,1,''),(28,'Signal conditioning',4,1,''),(29,'Identification and security',4,1,''),(31,'Microprocessors',4,1,''),(32,'Logic',4,1,''),(33,'Media processors',4,1,''),(35,'RF-Sensors',4,1,''),(36,'Electronic shopping',5,1,''),(37,'Reservation',5,1,''),(38,'Check-in and booking of reserved places',5,1,''),(40,'Coupons',5,1,''),(41,'Rebates',5,1,''),(42,'Advertisements',5,1,''),(43,'And point of sale',5,1,''),(44,'Tablets',6,1,''),(45,'Cameras',6,1,'THis is the explanation for HDTV'),(46,'HDTV',6,1,'THis is the explanation for HDTV'),(47,'Notebook',6,1,''),(48,'PC',6,1,''),(49,'GPS',6,1,''),(50,'Smartphones',7,1,''),(51,'Base stations',7,1,''),(52,'Mobile operating systems and applications',7,1,''),(53,'Vehicle subsystem or accessory control',8,1,''),(54,'Electric vehicle',8,1,''),(55,'Fuel injection control',8,1,''),(56,'Telephonic Communications',9,1,'\nTelegraphic Communication'),(57,'Multiplex Communications',9,1,''),(58,'Multicomputer Data Transferring',9,1,''),(59,'Light emitting diodes',10,1,''),(60,'Liquid crystal cells',10,1,''),(61,'Display elements arranged in matrix',10,1,''),(62,'Cargo',11,1,''),(63,'Inventory',11,1,''),(64,'Management',11,1,''),(65,'TV services',12,1,''),(66,'Set-Top Boxes',12,1,''),(67,'ISP services',12,1,''),(68,'Video conferencing',12,1,''),(69,'Multimedia services',12,1,''),(70,'Online video services',12,1,''),(71,'CDN',12,1,''),(73,'Contract Lawyers',0,0,''),(74,'Patent Prosecutors',0,0,''),(75,'Patent Litigators',0,0,''),(76,'Social Media Marketing',0,0,''),(77,'Journalists',0,0,''),(78,'Patent Enforcers',0,0,''),(79,'Brokers',0,0,''),(81,'TechExperts',0,0,''),(83,'Pools and Outdoors',10,1,''),(85,'Patent Research (Law)',0,0,''),(86,'Patent Research (Law + Tech)',0,0,''),(87,'Fuel injection control Focus',8,1,''),(88,'Hybrid',8,1,''),(89,'Hybrid brakes',8,1,''),(90,'Steering wheels',8,1,''),(91,'Proximity sensoring',8,1,''),(93,'Advertising Systems/Solutions',5,1,'Web systems aimed to help vendors be seen by potential customers based on different factors and parameters.'),(94,'Toll-Free Call Routing',5,1,'Telephone numbers in which the calling party is not charged for the call by the telephone carrier.'),(95,'Online Search Portals',5,1,'Specially designed web site that brings information together from diverse sources in a uniform way.'),(96,'Vanity Numbers - Call Routing',5,1,'A telephone number for which a subscriber requests an easily remembered sequence of numbers for marketing purposes.'),(99,'Patent/Royalty Valuation',0,1,''),(100,'Royalty and Agreements database',0,1,''),(114,'Internet TV',46,1,'Digital distribution of television content, such as TV shows, via the public Internet. Digital distribution of television content, such as TV shows, via the public Internet.Digital distribution of television content'),(115,'Sound Systems',6,1,''),(116,'MP3 Players',115,1,'When a user interacts with the holographic image, the sensors sense the user interaction based on quadrilateral angle navigation. The information corresponding to the user interaction is provided to the processor by the sensors. Examples of the sensors include location sensors, motion sensors, light sensors and sound sensors'),(117,'Financial Services',3,1,''),(118,'Medical',1,1,'asd'),(119,'Computer Networks',9,1,'Switching, Synchronization, clock signals, Routing, SONET'),(120,'Networking',9,1,'Error Correction, Fault detection & recovery, Data Processing System, Multiplex Communication, Data switching networks, ');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-21 19:29:55
