-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: q3vtafztappqbpzn.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: uyfpb5wx6tnyzrhm
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backyard_chart_lefts`
--

DROP TABLE IF EXISTS `backyard_chart_lefts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backyard_chart_lefts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lead_id` int(11) NOT NULL,
  `country` varchar(150) NOT NULL,
  `applications` varchar(150) DEFAULT '0',
  `patents` varchar(150) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`)
) ENGINE=InnoDB AUTO_INCREMENT=969 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backyard_chart_lefts`
--

LOCK TABLES `backyard_chart_lefts` WRITE;
/*!40000 ALTER TABLE `backyard_chart_lefts` DISABLE KEYS */;
INSERT INTO `backyard_chart_lefts` VALUES (1,76,'US','6','10'),(2,76,'GE','8','12'),(3,76,'UK','4','8'),(4,76,'CH','5','10'),(92,188,'US','3',''),(103,25,'U.S.','','1'),(104,182,'US','31',''),(171,217,'US','6','1'),(768,93,'US','17',NULL),(776,275,'USA','0','1'),(894,265,'US','1','3'),(909,43,'US','1','2'),(916,201,'US','7',''),(917,404,'US','10','10'),(924,186,'US','10',''),(945,400,'US','1','2'),(946,400,'DE','1',''),(947,400,'GB','1',''),(948,400,'FR','1',''),(949,400,'CH','2',''),(950,227,'United States','1','5'),(963,127,'US','0','1'),(964,127,'DE','0','1'),(965,127,'FR','0','1'),(966,127,'GB','0','1'),(967,127,'IT','0','1'),(968,127,'CA','1','0');
/*!40000 ALTER TABLE `backyard_chart_lefts` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-21 19:33:45
