-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: q3vtafztappqbpzn.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: uyfpb5wx6tnyzrhm
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `due_logtime`
--

DROP TABLE IF EXISTS `due_logtime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `due_logtime` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lead_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `project_type` int(11) NOT NULL,
  `total_patent` int(11) NOT NULL,
  `duration` varchar(20) NOT NULL,
  `create_date` datetime NOT NULL,
  `permmission` int(11) NOT NULL DEFAULT '1',
  `expert` text NOT NULL,
  `file_url` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `due_logtime`
--

LOCK TABLES `due_logtime` WRITE;
/*!40000 ALTER TABLE `due_logtime` DISABLE KEYS */;
INSERT INTO `due_logtime` VALUES (5,127,'Claim',4,1,'','2015-09-22 14:12:07',0,'satish.rana.k@gmail.com, webmaster@synpat.com, ',NULL),(6,220,'Claim',4,1,'','2015-09-22 14:35:05',1,'webmaster@synpat.com, ',NULL),(7,226,'Technical',2,1,'','2015-10-20 11:54:30',1,'uzi@synpat.com, ',NULL),(10,127,' a Docket Introduction',0,0,'','2015-10-21 07:39:17',1,'webmaster@synpat.com',NULL),(11,226,' a Docket Introduction',0,0,'','2015-10-21 15:56:33',1,'uzi@synpat.com',NULL),(12,227,'Technical',2,6,'','2015-12-20 18:25:24',0,'vinay.sharma@aranca.com, akhilesh.bhugra@aranca.com, ','Array'),(13,227,'Legal',3,6,'01:40:00','2015-12-20 18:28:42',1,'vinay.sharma@aranca.com, akhilesh.bhugra@aranca.com, ','Array'),(16,227,'Link to Seller',7,0,'','2016-04-05 10:23:27',1,'webmaster@synpat.com, ','javascript://'),(17,227,'Legal DD- Genedics',3,0,'01:40:00','2016-04-05 20:25:39',1,'webmaster@synpat.com, ','http://synpat.com/legaldd/22232'),(18,227,'Tech DD - Genedics',2,0,'07:18:30','2016-04-06 10:33:51',1,'neha.salgotra@winsomeip.com, ','http://synpat.com/techdd/22232'),(19,227,'Claim Illustration - Genedics - Genedics',4,0,'','2016-04-07 15:45:59',1,'satish.rana.k@gmail.com, ','https://docs.google.com/spreadsheets/d/1S08vzPgtJz8u2Ozh4G0N2S1D7EJyrv3bktn9oOTe_FI/edit?usp=drivesdk'),(22,230,'SynPat - Martin Munangatire - Independent Consulta',0,0,'','2016-04-08 14:02:24',1,'martinmunangatire@gmail.com,','https://docs.google.com/document/d/1Nt71M7vRTjJfwmIRH0joWVxRZ1DgmC8i-rudUnmIrKE/edit?usp=drivesdk'),(23,227,'Legal DD - Genedics',3,0,'01:40:00','2016-04-08 16:33:57',1,'j.talwar@ttconsultants.com, t.singh@ttconsultants.com, ','http://synpat.com/legaldd/22232'),(24,227,'Legal DD - Genedics',3,0,'01:40:00','2016-04-11 10:27:36',1,'satish.rana.k@gmail.com, ','http://synpat.com/legaldd/22232'),(25,227,'Comparable - Genedics',9,0,'00:30:00','2016-04-12 19:15:40',1,'webmaster@synpat.com, ','http://synpat.com/comparedd/22232'),(26,227,'Legal DD - Genedics',3,0,'01:40:00','2016-04-13 23:29:02',1,'tarun@iiprd.com, ','http://synpat.com/legaldd/22232'),(27,227,'Chrome Extension.',0,0,'','2016-04-13 23:36:10',1,'tarun@iiprd.com, ',''),(28,227,'Comparable - Genedics',9,0,'00:30:00','2016-04-14 21:14:24',0,'satish.rana.k@gmail.com, ','http://synpat.com/comparedd/22232'),(29,265,'EoU-CC-Metro Dynamic Call Routing &amp; Google Ads',0,0,'','2016-05-13 09:59:22',1,'neha.salgotra@winsomeip.com, neha.salgotra84@gmail.com, ','https://drive.google.com/file/d/0B61I0m5ybHrFa3JVTFNTeUd1RzA/view?usp=drivesdk'),(30,265,'EoU-CC-Metro Dynamic Call Routing &amp; Google Ads',0,0,'','2016-05-13 13:07:27',1,'uzi@synpat.com, ','https://drive.google.com/file/d/0B61I0m5ybHrFa3JVTFNTeUd1RzA/view?usp=drivesdk'),(31,265,'Claim Illustration - Metro Enterprises Inc - Metro',4,0,'838:59:59','2016-05-18 07:42:35',1,'uzi@synpat.com, ','https://docs.google.com/spreadsheets/d/1iT5raTsQwR75v72LOWVlx5VQlYOJeagmgJoHc2Tg5C8/edit?usp=drivesdk'),(32,265,'Legal DD - Metro Enterprises Inc',3,0,'06:13:22','2016-05-18 07:51:11',1,'tarun@iiprd.com, ','http://synpat.com/legaldd/85865'),(33,150,'Comparable - SynPat - Research',9,0,'02:10:16','2016-05-20 09:39:45',0,'subhranshus@gmail.com, ','http://synpat.com/comparedd/48618244'),(39,227,'CHeck where it goes',6,6,'','2016-06-13 18:51:01',1,'er.vivek2512@gmail.com, ','https://docs.google.com/spreadsheets/d/1kUPX0_9tFjjhwSscr-JtOr7tMgcMCGy-mV62TrkEIfU/edit?usp=drivesdk'),(45,150,'Comparable - SynPat - Research',9,0,'08:06:16','2016-06-15 21:09:58',0,'srinivas.ipr@gmail.com, ','http://synpat.com/comparedd/48618244'),(46,265,'Tech DD - Metro Enterprises Inc',2,4,'06:33:21','2016-06-17 14:22:04',1,'uzi@synpat.com, ','http://synpat.com/techdd/85865'),(47,150,'Comparable - SynPat - Research',9,0,'00:49:20','2016-06-17 16:11:02',1,'uzi@synpat.com, ','http://synpat.com/comparedd/48618244'),(48,265,'Intro Images - Metro Enterprises Inc',11,4,'','2016-06-17 20:16:29',1,'webmaster@synpat.com, ','http://synpat.com/introimages/index/85865'),(49,265,'Tech DD - Metro Enterprises',2,4,'06:33:21','2016-06-21 01:50:00',1,'Tanbsngh@gmail.com, ','http://synpat.com/techdd/85865'),(50,150,'Comparable - SynPat - Research',9,0,'00:19:46','2016-06-23 00:50:56',0,'harsharohatgi@gmail.com, ','http://synpat.com/comparedd/48618244'),(51,150,'Comparable - SynPat - Research',9,0,'13:41:03','2016-06-23 00:54:32',1,'dhanura@gmail.com, ','http://synpat.com/comparedd/48618244'),(52,265,'Intro DD - Metro Enterprises',8,4,'','2016-06-23 10:46:46',1,'uzi@synpat.com, ','http://synpat.com/store/Metro_Enterprises/?edit'),(53,265,'Comparable - Metro Enterprises',9,4,'','2016-06-23 11:21:13',1,'uzi@synpat.com, ','http://synpat.com/comparedd/85865'),(54,150,'Tech DD - SynPat - Research',2,0,'','2016-06-26 19:15:37',1,'er.vivek2512@gmail.com, ','http://synpat.com/techdd/48618244'),(56,354,'techDD',2,0,'','2016-09-27 23:06:01',1,'uzi@synpat.com, ','http://synpat.com/techdd/47899'),(67,400,'illustrations for BT',4,6,'01:23:58','2016-11-03 12:54:41',1,'webmaster@synpat.com, ','http://synpat.com/illustrationdd/index/37166'),(68,400,'Patent Ilulstrations - Test',4,6,'01:23:58','2016-11-03 15:41:40',1,'uzi@synpat.com, ','http://synpat.com/illustrationdd/index/37166'),(69,400,'BT: WiFi offload - LTE (3GPP) - Claim Illustration',4,6,'00:03:28','2016-11-07 12:15:34',1,'payal.567@gmail.com, ','http://synpat.com/illustrationdd/index/37166'),(70,400,'test legal dd',3,6,'00:06:36','2016-11-07 12:29:59',1,'uzi@synpat.com, ','http://synpat.com/legaldd/37166'),(71,400,'Legal DD - test',3,6,'00:06:36','2016-11-07 12:32:10',0,'uzi@ilvrge.com, ','http://synpat.com/legaldd/37166'),(72,400,'Legal DD - BT: WiFi offload - LTE (3GPP)',3,6,'00:06:36','2016-11-07 13:18:47',0,'er.vivek2512@gmail.com, ','http://synpat.com/legaldd/37166'),(73,400,'Legal DD - BT: WiFi offload - LTE (3GPP)',3,6,'00:06:36','2016-11-07 13:25:47',1,'er.vivek2512@gmail.com, ','http://synpat.com/legaldd/37166'),(74,400,'Tech dd test',2,6,'01:05:55','2016-11-08 00:29:18',1,'uzi@ilvrge.com, ','http://synpat.com/techdd/37166'),(75,400,'BT: WiFi offload - LTE (3GPP) - Tech DD',2,6,'02:10:13','2016-11-09 13:30:13',1,'amit@anovip.com, ','http://synpat.com/techdd/37166'),(76,467,'legal dd - test',3,0,'00:22:05','2016-11-16 01:18:20',1,'uzi@ilvrge.com, ','http://synpat.com/legaldd/71627'),(77,467,'Ciena - Optical Networking - Legal DD',3,0,'00:22:05','2016-11-16 15:31:31',1,'dhruva.s@idsil.com, ','http://synpat.com/legaldd/71627'),(78,467,'Ciena - Optica Networking - Tech DD',2,0,'01:10:11','2016-11-16 15:33:19',1,'dhruva.s@idsil.com, ','http://synpat.com/techdd/71627'),(79,467,'Ciena - Optical Networking - Claim Illustrations',4,0,'','2016-11-16 16:01:27',1,'dhruva.s@idsil.com, ','http://synpat.com/illustrationdd/index/71627');
/*!40000 ALTER TABLE `due_logtime` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-21 19:34:34
