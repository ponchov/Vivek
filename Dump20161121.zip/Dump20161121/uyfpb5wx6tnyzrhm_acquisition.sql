-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: q3vtafztappqbpzn.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: uyfpb5wx6tnyzrhm
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `acquisition`
--

DROP TABLE IF EXISTS `acquisition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `acquisition` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lead_id` int(11) NOT NULL,
  `market_sector` int(11) NOT NULL,
  `seller_upfront` decimal(10,1) NOT NULL,
  `no_of_patent` int(11) NOT NULL,
  `no_of_sep` int(11) NOT NULL DEFAULT '0',
  `no_of_potential_licensees` int(11) NOT NULL DEFAULT '0',
  `store_name` varchar(50) NOT NULL DEFAULT '',
  `create_date` datetime NOT NULL,
  `option_expiration_data` varchar(50) NOT NULL DEFAULT '',
  `image_left` text NOT NULL,
  `image_middle` text NOT NULL,
  `image_right` text NOT NULL,
  `image_four` text NOT NULL,
  `image_five` text NOT NULL,
  `image_six` text NOT NULL,
  `image_seven` text NOT NULL,
  `image_eight` text NOT NULL,
  `image_nine` text NOT NULL,
  `image_ten` text NOT NULL,
  `image_eleven` text NOT NULL,
  `image_twelve` text NOT NULL,
  `seller_asking_price` float(10,1) NOT NULL DEFAULT '0.0',
  `other_damages` text NOT NULL,
  `ppa` text NOT NULL,
  `pla` text NOT NULL,
  `rtp` text NOT NULL,
  `sla` text NOT NULL,
  `ppp` text NOT NULL,
  `damage` text NOT NULL,
  `syndication` text NOT NULL,
  `cc_embed_code` text NOT NULL,
  `order_name` varchar(100) NOT NULL,
  `par_embed_code` text NOT NULL,
  `assets_id` varchar(100) NOT NULL,
  `ppa_id` varchar(100) NOT NULL,
  `nda_id` varchar(100) NOT NULL,
  `category` int(11) NOT NULL,
  `active_button` int(11) NOT NULL,
  `potential_participants` int(11) NOT NULL,
  `final_participants` int(11) NOT NULL,
  `regular_license_starts` datetime NOT NULL,
  `late_license_starts` datetime NOT NULL,
  `store` text NOT NULL,
  `cost_price` varchar(50) NOT NULL DEFAULT '0.0',
  `docket_status` tinyint(1) DEFAULT '0',
  `old_category` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`),
  KEY `store_name` (`store_name`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acquisition`
--

LOCK TABLES `acquisition` WRITE;
/*!40000 ALTER TABLE `acquisition` DISABLE KEYS */;
INSERT INTO `acquisition` VALUES (20,133,0,0.0,0,0,0,'Rahul','2015-06-02 05:54:20','','','','','','','','','','','','','',0.0,'','','','','','','','','','','','','','',0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','0.0',0,0),(23,43,0,0.0,0,0,0,'Sun_Management','2015-06-08 13:38:40','09/15/2015','https://www.googledrive.com/host/0B-7JHq4pougDYWxETXBXeVVfOWc','https://www.googledrive.com/host/0B-7JHq4pougDMnpjZXdYNEhYN28','https://www.googledrive.com/host/0B-7JHq4pougDS2RrYWhzQWtydFU','','','','','','','','','',0.6,'','https://drive.google.com/file/d/0B61I0m5ybHrFZ0c1Vmo4bWxhNlE/view?usp=drivesdk','https://docs.google.com/document/d/1-2a1VddkLFoiAmLRrXGxrtrwNel6mGdzkA959EHfOos/edit?usp=drivesdk','https://docs.google.com/document/d/15hRuxa6NbNkEqDtAeCvSIqyoAzeYQObnRLO-s_AQJ-A/edit?usp=drivesdk','https://docs.google.com/document/d/1z_GdjkyPjQRNxPSWC5WJwg_DswrotWhdAYOrVTxy4f4/edit?usp=drivesdk','https://docs.google.com/document/d/1Y0o8OyTnBvbXP6tLed_hc_Wya8r1p9l39Oqu4Os9wGs/edit?usp=drivesdk','','','<iframe src=\"http://claimcharts.info/index.php/component/survey/?tmpl=component&task=customer.generateClientRequest&client_id=Sun1&pr=2\" width=\"100%\" height=\"1000\" frameborder=\"0\" scrolling=\"yes\"></iframe>','Sun1','','','','',7,1,0,3,'2015-06-05 00:00:00','2015-10-06 00:00:00','This patent portfolio relates to Release 11 of the LTE 4G standard.','0.0',0,0),(24,141,0,0.0,0,0,0,'B3D_Inc.','2015-06-10 07:32:10','','','','','','','','','','','','','',1.3,'','','','','','','','','','','','','1u_s-CgzrGXUTZ7bZw7W0NUnb4DCQZ8HjVJMU__YB9PA','',0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','0.0',0,0),(27,127,0,0.0,0,0,0,'Gestion_Proche','2015-08-19 13:34:49','03/24/2016','https://www.googledrive.com/host/0B-7JHq4pougDQUF2QWRXT0huVzA','https://www.googledrive.com/host/0B61I0m5ybHrFT2pfNkNBTkdSRWc','https://www.googledrive.com/host/0B-7JHq4pougDSHRRTXg1QXdTd1k','https://www.googledrive.com/host/0B-7JHq4pougDMWJaSF9Kb2pTYVE','https://www.googledrive.com/host/0B-7JHq4pougDcVk1VUdGUWhxZlU','https://www.googledrive.com/host/0B-7JHq4pougDR0RIQmFFT3FwUkU','https://www.googledrive.com/host/0B-7JHq4pougDM1Z1dDZfVndmWk0','https://www.googledrive.com/host/0B-7JHq4pougDMmpsU2dGRlZKUVU','https://www.googledrive.com/host/0B-7JHq4pougDUElIVTRCWXp0M0k','https://www.googledrive.com/host/0B-7JHq4pougDTVJVWVlpR3hzbUE','https://www.googledrive.com/host/0B-7JHq4pougDdWxwZmVXUDJsQk0','',0.6,'','https://drive.google.com/file/d/0B61I0m5ybHrFc0V3M0VROHk5ekU/view?usp=drivesdk','https://docs.google.com/document/d/1yWPVuGkg_Zr2OuO7UjkcUHLkzGIMnumdAq6ZFnrvtCA/edit?usp=drivesdk','https://docs.google.com/document/d/1HdS8oHxO9_KkJr6SOmJYTcdKD2Cots5Xiy67qw5v1bs/edit?usp=drivesdk','https://docs.google.com/document/d/1Y8hYMfV6E0yd3v7Eq34rPZd3y1pqjdaM4ksCiYrnYWA/edit?usp=drivesdk','https://docs.google.com/document/d/1ZRRDNAAuXIJCsu3K2m8SisgvCAF7157h_6lTyrJv9S4/edit?usp=drivesdk','','','<iframe src=\"http://claimcharts.info/index.php/component/survey/?tmpl=component&task=customer.generateClientRequest&client_id=Gestion&pr=2\" width=\"100%\" height=\"680\" frameborder=\"0\" scrolling=\"yes\"></iframe>','Gestion','<iframe src=\"http://claimcharts.info/index.php/component/survey/?tmpl=component&task=customer.generateClientRequest&client_id=Gestion&pr=1\" width=\"100%\" height=\"680\" frameborder=\"0\" scrolling=\"no\"></iframe>','','','',6,1,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','This portfolio relates to an array of lighting devices, and covers a mechanism to maintain its luminosity. When the luminosity drops below a pre-determined level, a controller compensates by energizing one or more lighting devices within the array.','0.0',0,0),(28,188,0,0.0,0,0,0,'Hernandez_(4G_LTE_Infrastructure)','2015-08-25 18:09:19','','','','','','','','','','','','','',0.0,'','https://docs.google.com/document/d/1NsyMKdP3VmoruU7ZpSKcSVjRfxX8GHe9KQlY5-avGhU/edit?usp=drivesdk','','','','','','','','','','','','',0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','0.0',0,0),(29,25,0,0.0,0,0,0,'HP_-_Cable_Companies','2015-09-17 12:36:51','','','','','','','','','','','','','',0.0,'','','','','','','','','','','','','','',0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','0.0',0,0),(30,182,0,0.0,0,0,0,'Seoul_National_University','2015-09-17 19:41:50','','','','','','','','','','','','','',5.8,'','','','','','','','','','','','','','',0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','0.0',0,0),(31,190,0,0.0,0,0,0,'WiLan_(Het_Net)','2015-09-21 22:45:42','','','','','','','','','','','','','',1.5,'','','','','','','','','','','','','','',0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','0.0',0,0),(32,166,0,0.0,0,0,0,'Brokers','2015-09-27 22:34:22','','','','','','','','','','','','','',0.0,'','','','','','','','','','','','','','',0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','0.0',0,0),(33,217,0,0.0,0,0,0,'Gil_Thieberger','2015-09-29 11:16:51','','http://backyard.synpat.com/public/upload/','http://backyard.synpat.com/public/upload/','http://backyard.synpat.com/public/upload/','http://backyard.synpat.com/public/upload/','http://backyard.synpat.com/public/upload/','http://backyard.synpat.com/public/upload/','http://backyard.synpat.com/public/upload/','http://backyard.synpat.com/public/upload/','http://backyard.synpat.com/public/upload/','http://backyard.synpat.com/public/upload/','http://backyard.synpat.com/public/upload/','http://backyard.synpat.com/public/upload/',0.0,'','','','','','','','','','','','','','',0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','0.0',0,0),(35,143,0,0.0,0,0,0,'Pre-Lead','2015-10-01 15:44:12','','','','','','','','','','','','','',0.0,'','','','','','','','','','','','','','',0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','0.0',0,0),(36,97,0,0.0,0,0,0,'Auriga_Measurement_Systems_','2015-10-07 22:28:12','','','','','','','','','','','','','',0.0,'','','','','','','','','','','','','','',0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','0.0',0,0),(38,224,0,0.0,0,0,0,'Monkey_Media','2015-10-14 18:00:07','','','','','','','','','','','','','',0.0,'','https://docs.google.com/document/d/14kjd84q3EeU3aUyA97WdOzadi9vHC-zYVx4Uozi2U5Y/edit?usp=drivesdk','','','','','','','','','','','','',0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','0.0',0,0),(42,237,0,0.0,0,0,0,'Test_11','2015-11-03 23:44:16','','','','','','','','','','','','','',0.0,'','','','','','','','','','','','','1-71I3vJLuMYMe_PO5IHegvKBUDDyw0qkihJUg3DWS90','',0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','0.0',0,0),(44,240,0,0.0,0,0,0,'Test1','2015-11-04 02:17:45','','','','','','','','','','','','','',0.0,'','','','','','','','','','','','','','',0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','0.0',0,0),(45,230,0,0.0,0,0,0,'SynPat_-_Services','2015-12-02 15:14:16','','','','','','','','','','','','','',0.0,'','','','','','','','','','','','','','',0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','0.0',0,0),(46,210,0,0.0,0,0,0,'Callwave_Communications','2015-12-02 23:30:01','','','','','','','','','','','','','',0.0,'','','','','','','','','','','','','','',0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','0.0',0,0),(47,251,0,0.0,0,0,0,'Dashboard_Computing','2015-12-16 13:39:18','','','','','','','','','','','','','',0.0,'','https://docs.google.com/document/d/18BfFLw81o1s5rJYZfEj00AX-YCpwnqrsqdHzwd08nXU/edit?usp=drivesdk','','','','','','','','','','','','',0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','0.0',0,0),(48,227,0,0.0,0,0,0,'Genedics','2015-12-28 18:24:08','05/01/2016','https://www.googledrive.com/host/0B61I0m5ybHrFRW93YnA0eE8zLVk','https://www.googledrive.com/host/0B61I0m5ybHrFZVN0TTE0bndyOWs','https://www.googledrive.com/host/0B61I0m5ybHrFR3dIa3NCenRzbnc','https://www.googledrive.com/host/0B61I0m5ybHrFM1gtOTJGSC1zLTQ','https://www.googledrive.com/host/0B61I0m5ybHrFbzA1cjdyNlRHcVE','https://www.googledrive.com/host/0B61I0m5ybHrFV3gyemVJNWg2X1E','https://www.googledrive.com/host/0B61I0m5ybHrFMWZwSWZ6NmJ5ZDA','https://www.googledrive.com/host/0B61I0m5ybHrFUVZ0UnBuRHNwMlU','https://www.googledrive.com/host/0B61I0m5ybHrFZ2ZGNXlZZTUtVmM','https://www.googledrive.com/host/0B61I0m5ybHrFYlBoazZYd29vUGc','https://www.googledrive.com/host/0B61I0m5ybHrFbVRCaGVLVDl4R0k','https://www.googledrive.com/host/0B61I0m5ybHrFdm1RLVFHc3ZFSGM',1.0,'https://drive.google.com/file/d/0B61I0m5ybHrFeG5PRnVFTlkyeU0/edit?usp=drivesdk','https://drive.google.com/file/d/0B61I0m5ybHrFeWlrMHBoM3R3N3M/view?usp=drivesdk','https://docs.google.com/document/d/1zm_cnT35-h0AvmjbxCYr8ejECIk_n-z4VZNq6vWOd-k/edit?usp=drivesdk','https://docs.google.com/document/d/1aleBIUWF28fTnd1dYDtuCe7Tviz0xgWOZ2XXcm6aQL8/edit?usp=drivesdk','https://docs.google.com/document/d/1libmeQlQlt4DaamVqMoeE1TONgbfBb20XYueoOeYLB8/edit?usp=drivesdk','https://docs.google.com/document/d/1truUHFt-eDnqoSQ-4lBhGK5EtuCgCvYzZBm1rWxDF2o/edit?usp=drivesdk','','','<iframe src=\"http://claimcharts.info/index.php/component/survey/?tmpl=component&task=customer.generateClientRequest&client_id=Genedic&pr=2\" width=\"100%\" height=\"680\" frameborder=\"0\" scrolling=\"yes\"></iframe>','Genedic','','','','',6,1,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','This portfolio is directed to a user interface system that enables a user to interact with a 3D holographic image in a 3D coordinate system. Examples of the interaction include twisting, bending, cutting, displacing and squeezing the holographic image. ','1.0',0,0),(49,88,0,0.0,0,0,0,'Sony','2016-01-26 16:35:22','','','','','','','','','','','','','',0.0,'','https://docs.google.com/document/d/1ZQ37OxJ9bsQp6K9NCNEJz9vMqH7lKbUNa8nY6ILAmuU/edit?usp=drivesdk','','','','','','','','','','','','',0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','0.0',0,0),(50,93,0,0.0,0,0,0,'Beyond_Edison','2016-01-27 19:56:02','','','','','','','','','','','','','',0.8,'','','','','','','','','','','','','','',0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','0.0',0,0),(51,265,0,0.0,0,0,0,'Metro_Enterprises','2016-03-11 13:45:29','08/01/2016','https://www.googledrive.com/host/0B-7JHq4pougDMXpJS0dOV1pBa1k','https://www.googledrive.com/host/0B-7JHq4pougDSUJuZ2ZCM2I4aDQ','https://www.googledrive.com/host/0B61I0m5ybHrFdU1oa3dwcURIZ0k','https://www.googledrive.com/host/0B-7JHq4pougDWXJDUVk0Z2NzTEk','https://www.googledrive.com/host/0B61I0m5ybHrFYWNLclZWbnBGdVk','https://www.googledrive.com/host/0B61I0m5ybHrFYWxLU2cwYkRrQWM','https://www.googledrive.com/host/0B61I0m5ybHrFU0QtZmhxQW9vT0E','https://www.googledrive.com/host/0B-7JHq4pougDU0ZzRXVCY0MwYk0','https://www.googledrive.com/host/0B-7JHq4pougDYk5XQlFISTBjaVE','https://www.googledrive.com/host/0B61I0m5ybHrFU0QtZmhxQW9vT0E','','',0.6,'https://drive.google.com/a/synpat.com/file/d/0B61I0m5ybHrFUUdIaWJWNU91QjQ/view','https://docs.google.com/document/d/1Q1MuGCt-0kn8FqpX3DA1fRDaYIRBIcrd3uVWtvH9WsI/edit?usp=drivesdk','https://docs.google.com/document/d/1zXGMexeBRhIczzB-zhibmEKGV_NE_h77fcxpd9gwGBw/edit','https://docs.google.com/document/d/1xA_lN1lGSXeKEqHVv9oIySRV2mPljYTHj2Azgo7mGGY/edit','https://docs.google.com/document/d/1c5s9VXbCnFERsMgrz46VcjsJ0x5oMUymq5B6EUGSBlY/edit?usp=drivesdk','https://docs.google.com/document/d/18AmX-MHoWWnPms4cvVJqAlb4UtztbRe3utPO62GkFlU/edit?usp=drivesdk','','','<iframe src=\"http://claimcharts.info/index.php/component/survey/?tmpl=component&task=customer.generateClientRequest&client_id=Metro&pr=2\" width=\"100%\" height=\"680\" frameborder=\"0\" scrolling=\"yes\"></iframe>','Metro','','','','',5,2,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','\"Pay-per-Call\" - used by telephone lead sources who offer marketers to bid against one another for a per-call charge. When a lead source (e.g. as result of a customer\'s search query) receives a telephone call from a customer it routs it to the highest bidder. The subject matter is not a business method, but rather the enabling technology.','TBD',0,0),(53,275,0,0.0,0,0,0,'Test_for_Neha','2016-03-31 01:52:55','','','','','','','','','','','','','',0.0,'','','','','','','','','','','','','1prPLYD5r2GR_MzUf1dDarcp_N--cTwy-TS0n9SpUkxo','',0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','0.0',0,0),(54,107,0,0.0,0,0,0,'Fujitsu_Chat_Messaging','2016-04-07 21:40:29','','','','','','','','','','','','','',0.0,'','','','','','','','','','','','','','',0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','0.0',0,0),(55,150,0,0.0,0,0,0,'SynPat_-_Research','2016-05-18 17:10:36','','','','','','','','','','','','','',0.0,'','','','','','','','','','','','','','',0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','0.0',0,0),(56,242,0,0.0,0,0,0,'TestVivek99','2016-05-19 12:19:00','','','','','','','','','','','','','',0.0,'','https://docs.google.com/document/d/1G-O5ThMZI0o9WvuJCt5RPrSH_TDBPIMYzwZzclksh-U/edit?usp=drivesdk','https://docs.google.com/document/d/1CXeWJYvqaCJ7MDmrcIHAzlrUXDxKEXCj22T3fmOHOA4/edit?usp=drivesdk','','','','','','','','','','','',0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','0.0',0,0),(57,106,0,0.0,0,0,0,'57699','2016-08-24 23:47:01','','','','','','','','','','','','','',0.0,'','','','','','','','','','','','','','',0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','0.0',0,0),(58,405,0,0.0,0,0,0,'96554','2016-09-23 15:10:43','','','','','','','','','','','','','',4.5,'','https://docs.google.com/document/d/1gTNJEz9mquUVYW6apUsampv1gEaPsaIkJo5vmLgW6kU/edit?usp=drivesdk','','','','','','','','','','','','',0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','0.0',0,0),(59,201,0,0.0,0,0,0,'70664','2016-09-27 23:01:05','','','','','','','','','','','','','',0.0,'','','','','','','','','','','','','','',0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','0.0',0,0),(60,354,0,0.0,0,0,0,'47899','2016-09-27 23:08:41','','','','','','','','','','','','','',0.0,'','','','','','','','','','','','','','',0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','0.0',0,0),(61,284,0,0.0,0,0,0,'49038','2016-09-28 14:38:26','','','','','','','','','','','','','',0.0,'','','','','','','','','','','','','','',0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','0.0',0,0),(62,404,0,0.0,0,0,0,'61638','2016-10-03 04:35:15','','','','','','','','','','','','','',0.0,'','','','','','','','','','','','','1gA3UD_qbnWgVT97b8EqTsvr1LpJxzVEZP-U1UacTizw','',0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','0.0',0,0),(63,400,0,0.0,0,0,0,'37166','2016-10-31 13:03:25','','','','','','','','','','','','','',0.9,'','','','','','','','','','','','','','',9,1,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','0.0',0,0),(64,186,0,0.0,0,0,0,'12176','2016-10-31 15:20:54','','','','','','','','','','','','','',1.8,'','','','','','','','','','','','','','',9,1,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','0.0',0,0),(65,464,0,0.0,0,0,0,'49370','2016-11-03 02:13:19','','','','','','','','','','','','','',0.0,'','https://docs.google.com/document/d/1M5pKGpKDsU5tTy9-zTzg_2snemoJ0ZjUQRjPLJ_NW54/edit?usp=drivesdk','','','','','','','','','','','','',0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','0.0',0,0),(66,431,0,0.0,0,0,0,'65110','2016-11-03 13:54:22','','','','','','','','','','','','','',0.0,'','','','','','','','','','','','','','',0,0,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','0.0',0,0),(67,467,0,0.0,0,0,0,'71627','2016-11-16 01:33:32','','','','','','','','','','','','','',0.0,'','','','','','','','','','','','','','',9,1,0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00','','0.0',0,0);
/*!40000 ALTER TABLE `acquisition` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-21 19:38:24
