-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: q3vtafztappqbpzn.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: uyfpb5wx6tnyzrhm
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `presale_activity_log_detail`
--

DROP TABLE IF EXISTS `presale_activity_log_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `presale_activity_log_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lead_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `note` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `email_id` int(11) NOT NULL DEFAULT '0',
  `subject` varchar(300) NOT NULL,
  `activity_date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `company_id` (`company_id`),
  KEY `lead_id` (`lead_id`),
  KEY `contact_id` (`contact_id`),
  KEY `email_id` (`email_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `presale_activity_log_detail`
--

LOCK TABLES `presale_activity_log_detail` WRITE;
/*!40000 ALTER TABLE `presale_activity_log_detail` DISABLE KEYS */;
INSERT INTO `presale_activity_log_detail` VALUES (1,127,1,45,3,'<div><span style=\"font-size: 14px;\">Hi Rob, I saw on LinkedIn that you have connections with the licensing people at Osram - Silvanya, and I need help with introducing an opportunity to participate in funding a portfolio relating to an LED control system. Our standard finder\'s fee is 4%.</span></div><div><span style=\"font-size: 14px;\">Are you available to discuss today?</span></div><div><span style=\"font-size: 14px;\">Regards,</span></div><div><br></div><div><div style=\"\"><span style=\"font-size: 14px;\">Uzi</span></div></div><div style=\"\"><span style=\"font-size: 14px; color: rgb(0, 49, 99);\"><br></span></div><div style=\"\"><div><span style=\"border-top-width: 1px; border-top-style: solid; border-top-color: rgb(0, 0, 0); padding-top: 1px; font-size: 14px; font-weight: bold; color: rgb(0, 49, 99);\">Uzi Aloush</span></div><div><span style=\"font-size: 14px;\">CEO&nbsp;</span></div><div><span style=\"font-size: 14px; font-weight: bold; color: rgb(0, 49, 99);\">Syndicated Patent Acquisitions Corp.</span></div><div><span style=\"font-size: 14px;\">One Market - Spear Tower, 35th Floor&nbsp;</span></div><div><span style=\"font-size: 14px;\">San Francisco, CA 94105&nbsp;&nbsp;</span></div><div><span style=\"font-size: 14px;\">D: +1-415-805-8813, O:&nbsp;+1-415-805-8818&nbsp;</span></div><div><span style=\"font-size: 14px; text-decoration: underline;\"><a href=\"mailto:uzi@synpat.com\" target=\"_blank\">uzi@synpat.com</a></span></div><div><span style=\"font-size: 14px; color: rgb(107, 173, 222);\"><a href=\"http://www.synpat.com/\" target=\"_blank\" style=\"text-decoration: underline;\">www.synpat.com</a></span></div></div><div style=\"\"><div style=\"font-family: arial, sans-serif; line-height: normal;\"><br></div></div><br><br><br><br><br><div><span style=\"border-top:1px solid #000;padding-top:1px\"><b><font face=\"Arial\" color=\"#000066\">Uzi Aloush</font></b></span></div><div>CEO&nbsp;</div><div><font face=\"Arial\" color=\"#000066\"><b>Syndicated Patent Acquisitions Corp.</b></font></div><div><font face=\"Arial\">One Market - Spear Tower, 35th Floor&nbsp;</font></div><div><font face=\"Arial\"><font face=\"Arial\">San Francisco, CA 94105&nbsp;&nbsp;</font></font></div><div><font face=\"Arial\"><font face=\"Arial\">D: +1-415-805-8813, O:&nbsp;+1-415-805-8818, M:&nbsp;+1-415-902-5901&nbsp;</font></font></div><div><font face=\"Arial\"><font face=\"Arial\"><a href=\"mailto:uzi@synpat.com\" target=\"_blank\">uzi@synpat.com</a>&nbsp;</font></font></div><div><font face=\"Arial\"><font face=\"Arial\" color=\"#0000ff\"><a href=\"http://www.synpat.com\" target=\"_blank\">www.synpat.com</a>&nbsp;\n</font></font></div><div><font face=\"Arial\"><br></font></div><div><font face=\"Arial\">This message is intended only for the individual or entity to which it is addressed. It may contain information that is confidential or privileged. If the reader of this message is not the intended recipient, you are hereby notified that any dissemination, sharing or copying of this e-mail is strictly prohibited. If you receive this e-mail in error, please notify Syndicated Patent Acquisitions Corp. immediately by telephone or email, and delete the material from any computer. Thank you.</font></div>',10,2112,'Help in introducing an acquisition of an LED Control System patent portfolio (S/N 72101)','2016-02-16 16:29:41'),(2,127,410,45,3,'<br>Testing<br><br><br><br><div><span style=\"border-top:1px solid #000;padding-top:1px\"><b><font face=\"Arial\" color=\"#000066\">Rahul Kapoor</font></b></span></div><div>Web Master&nbsp;</div><div><font face=\"Arial\" color=\"#000066\"><b>Syndicated Patent Acquisitions Corp.</b></font></div><div><font face=\"Arial\">One Market - Spear Tower, 35th Floor&nbsp;</font></div><div><font face=\"Arial\"><font face=\"Arial\">San Francisco, CA 94105&nbsp;&nbsp;</font></font></div><div><font face=\"Arial\"><font face=\"Arial\">D: +91-947-879-3552, O:&nbsp;+1-415-805-8818, M:&nbsp;+91-181-464-5067&nbsp;</font></font></div><div><font face=\"Arial\"><font face=\"Arial\"><a href=\"mailto:webmaster@synpat.com\" target=\"_blank\">webmaster@synpat.com</a>&nbsp;</font></font></div><div><font face=\"Arial\"><font face=\"Arial\" color=\"#0000ff\"><a href=\"http://www.synpat.com\" target=\"_blank\">www.synpat.com</a>&nbsp;\n</font></font></div><div><font face=\"Arial\"><br></font></div><div><font face=\"Arial\">This message is intended only for the individual or entity to which it is addressed. It may contain information that is confidential or privileged. If the reader of this message is not the intended recipient, you are hereby notified that any dissemination, sharing or copying of this e-mail is strictly prohibited. If you receive this e-mail in error, please notify Syndicated Patent Acquisitions Corp. immediately by telephone or email, and delete the material from any computer. Thank you.</font></div>',1,2113,'Testing another','2016-02-16 17:01:21'),(3,127,410,45,3,'<div><span style=\"font-size: 14px;\">Dear Uzi</span></div><div><span style=\"font-size: 14px; line-height: 1.42857;\">I am contacting you to invite Daid Amar to participate in crowdfunding the acquisition of a patent portfolio relating to&nbsp;LED Control Systems, to be included in SynPat\'s leading-edge license store.</span><br></div><div><div style=\"\"><span style=\"font-size: 14px;\">Please see below for easy access to the portfolio. &nbsp;If you prefer a personalized tour of SynPat\'s platform, please contact us with your best availability.</span></div><div style=\"\"><span style=\"font-size: 14px;\"><br></span></div><div style=\"\"><span style=\"font-size: 14px;\">Regards,</span></div><div style=\"\"><span style=\"font-size: 14px;\">Uzi</span></div></div><div style=\"\"><span style=\"font-size: 14px; color: rgb(0, 49, 99);\"><br></span></div><div style=\"\"><div><span style=\"border-top-width: 1px; border-top-style: solid; border-top-color: rgb(0, 0, 0); padding-top: 1px; font-size: 14px; font-weight: bold; color: rgb(0, 49, 99);\">Uzi Aloush</span></div><div><span style=\"font-size: 14px;\">CEO&nbsp;</span></div><div><span style=\"font-size: 14px; font-weight: bold; color: rgb(0, 49, 99);\">Syndicated Patent Acquisitions Corp.</span></div><div><span style=\"font-size: 14px;\">One Market - Spear Tower, 35th Floor&nbsp;</span></div><div><span style=\"font-size: 14px;\">San Francisco, CA 94105&nbsp;&nbsp;</span></div><div><span style=\"font-size: 14px;\">D: +1-415-805-8813, O:&nbsp;+1-415-805-8818&nbsp;</span></div><div><span style=\"font-size: 14px; text-decoration: underline;\"><a href=\"mailto:uzi@synpat.com\" target=\"_blank\">uzi@synpat.com</a></span></div><div><span style=\"font-size: 14px; color: rgb(107, 173, 222);\"><a href=\"http://www.synpat.com/\" target=\"_blank\" style=\"text-decoration: underline;\">www.synpat.com</a></span></div></div><div style=\"\"><div style=\"font-family: arial, sans-serif; line-height: normal;\"><br></div></div><br><br><br><br><br><div><span style=\"border-top:1px solid #000;padding-top:1px\"><b><font face=\"Arial\" color=\"#000066\">Uzi Aloush</font></b></span></div><div>CEO&nbsp;</div><div><font face=\"Arial\" color=\"#000066\"><b>Syndicated Patent Acquisitions Corp.</b></font></div><div><font face=\"Arial\">One Market - Spear Tower, 35th Floor&nbsp;</font></div><div><font face=\"Arial\"><font face=\"Arial\">San Francisco, CA 94105&nbsp;&nbsp;</font></font></div><div><font face=\"Arial\"><font face=\"Arial\">D: +1-415-805-8813, O:&nbsp;+1-415-805-8818, M:&nbsp;+1-415-902-5901&nbsp;</font></font></div><div><font face=\"Arial\"><font face=\"Arial\"><a href=\"mailto:uzi@synpat.com\" target=\"_blank\">uzi@synpat.com</a>&nbsp;</font></font></div><div><font face=\"Arial\"><font face=\"Arial\" color=\"#0000ff\"><a href=\"http://www.synpat.com\" target=\"_blank\">www.synpat.com</a>&nbsp;\n</font></font></div><div><font face=\"Arial\"><br></font></div><div><font face=\"Arial\">This message is intended only for the individual or entity to which it is addressed. It may contain information that is confidential or privileged. If the reader of this message is not the intended recipient, you are hereby notified that any dissemination, sharing or copying of this e-mail is strictly prohibited. If you receive this e-mail in error, please notify Syndicated Patent Acquisitions Corp. immediately by telephone or email, and delete the material from any computer. Thank you.</font></div>',10,2114,'Invitation to Participate - LED Control Systems patent portfolio acquisition (S/N 72101)','2016-02-16 17:03:31');
/*!40000 ALTER TABLE `presale_activity_log_detail` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-21 19:37:54
