-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: q3vtafztappqbpzn.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: uyfpb5wx6tnyzrhm
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `lead_levels`
--

DROP TABLE IF EXISTS `lead_levels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lead_levels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lead_id` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_levels`
--

LOCK TABLES `lead_levels` WRITE;
/*!40000 ALTER TABLE `lead_levels` DISABLE KEYS */;
INSERT INTO `lead_levels` VALUES (1,69,5),(2,76,5),(3,77,5),(4,51,5),(5,78,5),(6,18,5),(7,90,5),(8,92,5),(9,90,5),(11,76,5),(12,9,5),(13,43,5),(14,138,5),(15,138,5),(16,137,5),(17,97,5),(18,147,5),(19,60,5),(20,148,5),(21,93,5),(22,155,5),(23,162,5),(24,133,5),(25,165,5),(26,88,5),(27,43,5),(28,141,5),(29,127,5),(30,127,5),(31,127,5),(32,188,5),(33,25,5),(34,182,5),(35,127,5),(36,166,5),(37,217,5),(38,43,5),(39,222,5),(40,143,5),(41,97,5),(42,221,5),(43,224,5),(44,226,5),(45,235,5),(46,236,5),(47,237,5),(48,239,5),(49,240,5),(50,230,5),(51,210,5),(52,251,5),(53,227,5),(54,88,5),(55,93,5),(56,265,5),(57,265,5),(58,275,5),(59,275,5),(60,227,5),(61,107,5),(62,150,5),(63,242,5),(64,106,5),(65,405,5),(66,201,5),(67,354,5),(68,404,5),(69,400,5),(70,186,5),(71,464,5),(72,464,5),(73,464,5),(74,431,5),(75,467,5);
/*!40000 ALTER TABLE `lead_levels` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-21 19:39:15
