-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: q3vtafztappqbpzn.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: uyfpb5wx6tnyzrhm
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `campaign_process`
--

DROP TABLE IF EXISTS `campaign_process`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `campaign_process` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lead_id` int(11) NOT NULL,
  `to` longtext,
  `type` tinyint(1) DEFAULT NULL,
  `subject` varchar(200) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `main_activity` tinyint(1) DEFAULT NULL,
  `campaign_date` datetime DEFAULT NULL,
  `campaign_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaign_process`
--

LOCK TABLES `campaign_process` WRITE;
/*!40000 ALTER TABLE `campaign_process` DISABLE KEYS */;
INSERT INTO `campaign_process` VALUES (20,127,'webmaster@synpat.com, uzi@synpat.com, david@synpat.com, roelof.van.langen@philips.com, brian.hinman@philips.com, arian.duijvestijn@philips.com, rjordan@hamline.edu, kevin@3m.com, greg@3m.com, ronald.courtney@siemens.com, richard.brait@siemens.com, Beat.Weibel@siemens.com, jsherinsky@orrick.com, roger.tu@foxconn.com, ben.sley@foxconn.com, tanaka@postman.riken.go.jp, gray.thomas@outlook.com, bcolombo@kmbs.konicaminolta.us, spencer.yu@auo.com, kevin_forrestal@fujifilm-ffem.com, rob.tuttle@onsemi.com, nagomi.tsuchida.ds@hitachi.com, michael.barrett@cirrus.com, mpremutico@udcoled.com, mark@phononic.com, david@mrbeams.com, CLipsey@relume.com, rob.verbeelen@schreder.com, ken.korea@samsung.com, jun.h.bang@samsung.com, hosikjang@samsung.com, daniel.shim@samsung.com, chris.byrne@samsung.com, andrew.hong@samsung.com, jmmiller@ra.rockwell.com, plongtin@nyx-hemera.com, gmolaro@leviton.com, CButtitta@leviton.com, philipr@ibexlighting.com, jhawkins@kenall.com, thomas.connelly@flextronics.com, steven.jackman@flextronics.com, jon.hoak@flextronics.com, chris.stratas@flextronics.com, johnakastelic@eaton.com, jayamurthy@eaton.com, IngoPluennecke@eaton.com, DidierPatry@eaton.com, tpincince@digitallumens.com, lruss@crestron.com, hmosolygo@crestron.com, george_brandes@cree.com, jongmin@lginnotek.com, kevin.simons@lumileds.com, changhae.park@nxp.com, aaron.waxler@nxp.com, subbu@ti.com, r-holland3@ti.com, p-mclarty1@ti.com, l-bassuk@TI.COM, ken@ti.com, jws@ti.com, dawn.jos@ti.com, c-brill@ti.com, andyzewdie@gmail.com, ttaich@pacbell.net, jesus.delcastillo@bridgelux.com, Brad.Bullington@bridgelux.com, saito.takao@jp.panasonic.com, preston.wells@dialight.com, msutsko@dialight.com, John.Peck@stryker.com, steve.geissler@schneider-electric.com, Saket.Sankhla@schneider-electric.com, paul.campbell@schneider-electric.com, rick.earlywine@acuitybrands.com, charles.fails@acuitybrands.com, katsuyuki.akutagawa@nichia.com, philip.ytterberg@ge.com, monty.wright@ge.com, Michael.Petracci@ge.com, jeffrey.b.parker@ge.com, daniel.potvin@ge.com, casey.hill@ge.com, yoshio.murai@toshiba.co.jp, rick.lin@gmail.com, mitch.hatsumi@toshiba.com, andrew.wright@haynesolutions.com, northernabyss@gmail.com, torsten.roeser@infineon.com, al.torressen@lsi.com, soonhee.jang@stratasys.com, brent.bondy@magna.com, sunbin@boe.com.cn, jonathan.plotkin@rexelholdingsusa.com, wThornton@hubbell-ltg.com, mwerr@hubbell-ltg.com, gmacdonald@hubbell.com, rmorin@ameresco.com, MapelliP@conedsolutions.com, j.shell@energysystemsgroup.com, scott.jacobson@honeywell.com, mary.newellmiller@honeywell.com, matthias.probst@jci.com, dhaines@pepcoenergy.com, jmabbott@junolightinggroup.com, cwalsh@junolightinggroup.com, dyu@daintree.net, jblack@rvlti.com, pamela.tracey@sylvania.com, jacob.eisenberg@osram.com, arunava.dutta@sylvania.com, andrew.martin@sylvania.com, ',3,'Invitation to Participate - LED Control Systems patent portfolio acquisition (S/N 72101)',10,1,'2016-02-06 00:37:40',71),(21,237,'webmaster@synpat.com, er.vivek2512@gmail.com, ',3,'Invitation to Participate - LED Control Systems patent portfolio acquisition (S/N 72101)',1,1,'2016-02-06 21:13:42',80),(22,237,'webmaster@synpat.com, er.vivek2512@gmail.com, ',3,'Invitation to Participate - LED Control Systems patent portfolio acquisition (S/N 72101)',1,1,'2016-02-06 21:19:16',81),(23,237,'webmaster@synpat.com, er.vivek2512@gmail.com, ',3,'Invitation to Participate - LED Control Systems patent portfolio acquisition (S/N 72101)',1,1,'2016-02-06 21:31:07',84),(24,237,'webmaster@synpat.com, er.vivek2512@gmail.com, ',3,'Invitation to Participate - LED Control Systems patent portfolio acquisition (S/N 72101)',1,1,'2016-02-06 21:45:10',86),(25,237,'webmaster@synpat.com, er.vivek2512@gmail.com, ',3,'Invitation to Participate - LED Control Systems patent portfolio acquisition (S/N 72101)',1,1,'2016-02-06 21:55:18',87),(26,237,'webmaster@synpat.com, er.vivek2512@gmail.com, ',3,'Invitation to Participate - LED Control Systems patent portfolio acquisition (S/N 72101)',1,1,'2016-02-06 22:34:51',85),(27,237,'webmaster@synpat.com, er.vivek2512@gmail.com, ',3,'Invitation to Participate - LED Control Systems patent portfolio acquisition (S/N 72101)',1,1,'2016-02-08 17:54:00',88),(29,127,'jeffrey.b.parker@ge.com, alexander.han@samsung.com, ',3,'Invitation to Participate - LED Control Systems patent portfolio acquisition (S/N 72101)',10,1,'2016-02-23 16:20:37',91),(31,127,'scott.kirchner@us.panasonic.com, damien.atkins@us.panasonic.com, mklein@cusa.canon.com, ',3,'Invitation to Participate - LED Control Systems patent portfolio acquisition (S/N 72101)',10,1,'2016-03-15 10:55:01',116),(32,127,'shawn.toney@lsi-industries.com, ',3,'Invitation to Participate - LED Control Systems patent portfolio acquisition (S/N 72101)',10,1,'2016-03-15 17:35:57',117),(33,127,'scott.kirchner@us.panasonic.com, wittenburg@merl.com, ',3,'Invitation to Participate - LED Control Systems patent portfolio acquisition (S/N 72101)',10,1,'2016-03-16 15:59:16',118),(34,263,'satish.rana.k@gmail.com, ',3,'Request Confirmation',10,1,'2016-03-16 16:06:52',119),(35,263,'satish.rana.k@gmail.com, ',3,'Request Confirmation',1,1,'2016-03-16 16:19:21',116),(36,263,'satish.rana.k@gmail.com, ',3,'Request Confirmation',1,1,'2016-03-16 16:22:34',117),(38,263,'webmaster@synpat.com, ',3,'Request Confirmation',1,1,'2016-03-17 19:23:25',124),(41,263,'uzi@synpat.com, ',3,'Request Confirmation',10,1,'2016-03-18 15:30:12',129),(42,127,'randy.clayton@autani.com, ',3,'Invitation to Participate - LED Control Systems patent portfolio acquisition (S/N 72101)',10,1,'2016-03-21 14:49:32',130),(43,263,'webmaster@synpat.com, ',3,'Request Confirmation',1,1,'2016-03-21 15:09:26',131),(44,263,'webmaster@synpat.com, ',3,'Request Confirmation',1,1,'2016-03-21 19:05:28',132),(45,263,'webmaster@synpat.com, ',3,'Request Confirmation',1,1,'2016-03-22 13:36:18',133),(46,263,'webmaster@synpat.com, ',3,'Request Confirmation',1,1,'2016-03-22 19:39:33',134),(47,127,'plongtin@nyx-hemera.com, ',3,'Invitation to Participate - LED Control Systems patent portfolio acquisition (S/N 72101)',10,1,'2016-03-23 12:00:01',135),(48,244,'uzi@synpat.com, ',3,'Invitation to Participate - LED Control Systems patent portfolio acquisition (S/N 72101)',10,1,'2016-05-26 20:12:48',136),(49,265,'service@paypal.com, webmaster@synpat.com, uzi@synpat.com, ',3,'Invitation to Participate - Pay-per-Call patent portfolio acquisition (S/N 85865)',10,1,'2016-07-25 19:55:26',137);
/*!40000 ALTER TABLE `campaign_process` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-21 19:28:06
