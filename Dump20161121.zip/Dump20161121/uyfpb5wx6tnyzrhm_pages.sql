-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: q3vtafztappqbpzn.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: uyfpb5wx6tnyzrhm
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_name` varchar(100) NOT NULL,
  `page_url` varchar(300) NOT NULL,
  `parent` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,'Leads> Create >From Litigation','leads/litigation','Litigation'),(2,'Leads> Review >From Litigation','leads/litigation_review','Litigation'),(3,'Leads > Execute > From Litigation','leads/litigation_execute','Litigation'),(4,'Leads> Create >From Market','leads/market','Market'),(5,'Leads> Review >From Market','leads/market_review','Market'),(6,'Leads> Execute >From Market','leads/market_execute','Market'),(7,'General Setting >Create Opportunity','general/create_opportunity','General'),(8,'Leads> Create >Proactive General','leads/prospect_general','Proactive General'),(9,'Leads> Review >Proactive General','leads/prospect_general_review','Proactive General'),(10,'Leads> Execute >Proactive General','leads/prospect_general_execute','Proactive General'),(11,'General Setting >Manage Opportunity Type','general/manage_opportunity_type','General'),(12,'General Setting >Manage Sectors','general/manage_sectors','General'),(13,'General Setting >User Permissions','general/user_permissions','General'),(14,'General Setting >Add User','general/add_user','General'),(15,'General Setting >User List','general/userList','General'),(16,'Opportunities','opportunity/opportunity_list',''),(17,'Leads> Create >Proactive SEP','leads/proactive_sep','Proactive SEP'),(18,'Leads> Review >Proactive SEP','leads/proactive_sep_review','Proactive SEP'),(19,'Leads> Execute >Proactive SEP','leads/proactive_sep_execute','Proactive SEP'),(20,'General Setting >Manage Task','general/manage_task','General');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-21 19:35:02
