-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: q3vtafztappqbpzn.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: uyfpb5wx6tnyzrhm
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `lead_template_files`
--

DROP TABLE IF EXISTS `lead_template_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lead_template_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lead_id` int(11) NOT NULL,
  `file_name` varchar(500) NOT NULL,
  `name` varchar(100) NOT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `type` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_template_files`
--

LOCK TABLES `lead_template_files` WRITE;
/*!40000 ALTER TABLE `lead_template_files` DISABLE KEYS */;
INSERT INTO `lead_template_files` VALUES (1,133,'https://new-backyard.herokuapp.com/public/upload/html/1331440628723.html','Template-1',NULL,0),(2,133,'https://new-backyard.herokuapp.com/public/upload/html/1331440631759.html','Template-2',NULL,0),(3,43,'https://new-backyard.herokuapp.com/public/upload/html/431442531291.html','Sun Management - Example test 1',NULL,0),(8,133,'https://new-backyard.herokuapp.com/public/upload/html/1331447049012.html','LinkedIn template file','LinkedIn Template Message',1),(18,43,'https://new-backyard.herokuapp.com/public/upload/html/431447859136.html','Invitation to Participate','Invitation to Participant',0),(19,43,'https://new-backyard.herokuapp.com/public/upload/html/431447859428.html','Invitation to Participate - Linkedin/Email','____ patent portfolio - Invitation to Participate',1),(20,240,'https://new-backyard.herokuapp.com/public/upload/html/2401449125616.html','Invitation to Participate - Linkedin/Email','____ patent portfolio - Invitation to Participate',1),(21,240,'https://new-backyard.herokuapp.com/public/upload/html/2401449125630.html','Invitation to Participate','Invitation to Participant',0),(22,261,'https://new-backyard.herokuapp.com/public/upload/html/2611449816808.html','Invitation to Participate','Invitation to Participant',0),(23,261,'https://new-backyard.herokuapp.com/public/upload/html/2611449816834.html','Invitation to Participate - Linkedin/Email','____ patent portfolio - Invitation to Participate',1),(24,263,'https://new-backyard.herokuapp.com/public/upload/html/2631451305437.html','Invitation to Participate','Invitation to Participant',0),(25,263,'https://new-backyard.herokuapp.com/public/upload/html/2631451305467.html','SS','Request Confirmation',1),(49,127,'https://new-backyard.herokuapp.com/public/upload/html/1271454346810.html','Invitation to Participate New','Invitation to Participate - LED Control Systems Patent Portfolio acquisition (ref # 72101)',0),(58,237,'https://new-backyard.herokuapp.com/public/upload/html/2371454792910.html','Invitation to Participate','Invitation to Participate - LED Control Systems Patent Portfolio acquisition (ref # 72101)',0),(59,237,'https://new-backyard.herokuapp.com/public/upload/html/2371454792922.html','Invitation to Participate - Linkedin/Email','Invitation to Participate - LED Control Systems patent portfolio acquisition (S/N 72101)',1),(61,127,'https://new-backyard.herokuapp.com/public/upload/html/1271456794218.html','Invitation to Participate - Linkedin/Email','Invitation to Participate - LED Control Systems patent portfolio acquisition (S/N 72101)',1),(62,262,'https://new-backyard.herokuapp.com/public/upload/html/2621460656425.html','Invitation to Participate','Invitation to Participate - Virtual Reality Patent Portfolio acquisition (ref # 72101)',0),(63,262,'https://new-backyard.herokuapp.com/public/upload/html/2621460656629.html','Invitation to Participate - Linkedin/Email','Invitation to Participate',1),(64,280,'https://new-backyard.herokuapp.com/public/upload/html/2801460752429.html','Invitation to Participate','Invitation to Participate - Virtual Reality Control Systems Patent Portfolio acquisition (ref # 7210',0),(65,227,'https://new-backyard.herokuapp.com/public/upload/html/2271462994526.html','Invitation to Participate','Invitation to Participate - LED Control Systems Patent Portfolio acquisition (ref # 72101)',0),(66,266,'https://new-backyard.herokuapp.com/public/upload/html/2661464300281.html','Invitation to Participate','Invitation to Participate - Simple',0),(70,244,'https://new-backyard.herokuapp.com/public/upload/html/2441464310949.html','Invitation to Participate - Linkedin/Email','Invitation to Participate - LED Control Systems patent portfolio acquisition (S/N 72101)',1),(73,244,'https://new-backyard.herokuapp.com/public/upload/html/2441464311406.html','Invitation to Participate','Invitation to Participate - LED Control Systems Patent Portfolio acquisition (ref # 72101)',0),(76,265,'https://new-backyard.herokuapp.com/public/upload/html/2651469483693.html','Invitation to Participate','Invitation to Participate - Pay per Call Patent Portfolio acquisition (ref # 85865)',0),(78,265,'https://new-backyard.herokuapp.com/public/upload/html/2651469489577.html','Invitation to Participate - Linkedin/Email','Invitation to Participate - Pay-per-Call patent portfolio acquisition (S/N 85865)',1);
/*!40000 ALTER TABLE `lead_template_files` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-21 19:36:46
