-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: q3vtafztappqbpzn.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: uyfpb5wx6tnyzrhm
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `due_dilligence_standards`
--

DROP TABLE IF EXISTS `due_dilligence_standards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `due_dilligence_standards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patent_id` varchar(30) NOT NULL,
  `sdo` varchar(400) NOT NULL,
  `working_group` varchar(400) NOT NULL,
  `start_date` varchar(50) NOT NULL,
  `participants_claim` int(11) NOT NULL,
  `patent_file` varchar(400) NOT NULL,
  `commitment_file` varchar(500) NOT NULL,
  `knowledge` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=180 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `due_dilligence_standards`
--

LOCK TABLES `due_dilligence_standards` WRITE;
/*!40000 ALTER TABLE `due_dilligence_standards` DISABLE KEYS */;
INSERT INTO `due_dilligence_standards` VALUES (1,'US6845097','SDO0','Working Group0','2014-03-17 00:00:00',0,'776833468_1395211305Screenshot from 2014-03-04 16:39:18.png','1227376681_1395211305Screenshot from 2013-01-01 17:55:00.png',0),(2,'US6909878','','','1969-12-31 00:00:00',0,'776833468_1395211305Screenshot from 2014-03-04 16:39:18.png','1227376681_1395211305Screenshot from 2013-01-01 17:55:00.png',0),(3,'US6957045','','','0000-00-00 00:00:00',0,'776833468_1395211305Screenshot from 2014-03-04 16:39:18.png','1227376681_1395211305Screenshot from 2013-01-01 17:55:00.png',0),(4,'US7013112','','','0000-00-00 00:00:00',0,'776833468_1395211305Screenshot from 2014-03-04 16:39:18.png','1227376681_1395211305Screenshot from 2013-01-01 17:55:00.png',0),(5,'US7016334','','','0000-00-00 00:00:00',0,'776833468_1395211305Screenshot from 2014-03-04 16:39:18.png','1227376681_1395211305Screenshot from 2013-01-01 17:55:00.png',0),(6,'US6909878','','','1969-12-31 00:00:00',0,'','',0),(7,'US5379764','WSA','EDSE','2015-03-27 00:00:00',1,'','',1),(8,'US6283831','Yahoo','Private','2014-12-04 00:00:00',1,'','',1),(9,'US6776588','','','0000-00-00 00:00:00',0,'','',1),(10,'US7653456','','','0000-00-00 00:00:00',0,'','',1),(11,'US6283831','Mitsubishi Denki Kabus','SA','2014-12-08 00:00:00',1,'','',1),(12,'US6776588','','','0000-00-00 00:00:00',0,'','',1),(13,'US7653456','','','0000-00-00 00:00:00',0,'','',1),(14,'US6547651','','','0000-00-00 00:00:00',0,'','',1),(15,'US6789876','','','0000-00-00 00:00:00',0,'','',1),(16,'US6790431','','','0000-00-00 00:00:00',0,'','',1),(17,'US6787874','','','0000-00-00 00:00:00',0,'','',1),(18,'US7845654','','','0000-00-00 00:00:00',0,'','',1),(26,'US8338331','','','1969-12-31 00:00:00',0,'','',0),(27,'US8338340','','','0000-00-00 00:00:00',0,'','',0),(28,'US8338343','','','1969-12-31 18:00:00',0,'','',0),(29,'US8338339','','','1969-12-31 18:00:00',0,'','',0),(30,'US8338340','','','0000-00-00 00:00:00',0,'','',0),(31,'US8338341','','','0000-00-00 00:00:00',0,'','',0),(32,'US8338342','','','0000-00-00 00:00:00',0,'','',0),(33,'US8909824','','','1969-12-31 00:00:00',0,'','',0),(34,'US8386667','','','-0001-11-30 00:00:00',0,'','',0),(35,'US7557524','','','',0,'','',0),(171,'US7076037B1','','','0000-00-00 00:00:00',0,'','',0),(172,'US7953416B2','','','0000-00-00 00:00:00',0,'','',0),(173,'US8200231B2','','','0000-00-00 00:00:00',0,'','',0),(174,'US20070269038A1','','','0000-00-00 00:00:00',0,'','',0),(175,'AU2005319281','','','0000-00-00 00:00:00',0,'','',0),(176,'JP4774058B2','','','0000-00-00 00:00:00',0,'','',0),(177,'WO2008008993','','','0000-00-00 00:00:00',0,'','',0),(178,'AU2007272342','','','0000-00-00 00:00:00',0,'','',0),(179,'CA2650115A1','','','0000-00-00 00:00:00',0,'','',0);
/*!40000 ALTER TABLE `due_dilligence_standards` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-21 19:37:33
