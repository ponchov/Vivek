-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: q3vtafztappqbpzn.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: uyfpb5wx6tnyzrhm
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backyard_potential_syndicates`
--

DROP TABLE IF EXISTS `backyard_potential_syndicates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backyard_potential_syndicates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lead_id` int(11) NOT NULL,
  `participate` varchar(50) NOT NULL,
  `fees` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1780 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backyard_potential_syndicates`
--

LOCK TABLES `backyard_potential_syndicates` WRITE;
/*!40000 ALTER TABLE `backyard_potential_syndicates` DISABLE KEYS */;
INSERT INTO `backyard_potential_syndicates` VALUES (1,76,'1','6'),(2,76,'2','3'),(3,76,'3','2'),(4,76,'4','1.5'),(5,76,'5','1.2'),(6,76,'6','1'),(7,76,'7','0.857'),(8,76,'8','0.75'),(9,76,'1','6'),(10,76,'2','3'),(11,76,'3','2'),(12,76,'4','1.5'),(13,76,'5','1.2'),(14,76,'6','1'),(15,76,'7','0.857'),(16,76,'8','0.75'),(1620,265,'1','0.6'),(1621,265,'2','0.3'),(1622,265,'3','0.2'),(1623,265,'4','0.15'),(1624,265,'5','0.12'),(1625,265,'6','0.1'),(1626,265,'7','0.087'),(1627,265,'8','0.075'),(1628,265,'9','0.07'),(1629,265,'10','0.06'),(1742,43,'1','0.6'),(1743,43,'2','0.3'),(1744,43,'3','0.2'),(1745,43,'4','0.15'),(1746,43,'5','0.12'),(1747,43,'6','0.1'),(1754,227,'1','1'),(1755,227,'2','0.5'),(1756,227,'3','0.33'),(1757,227,'4','0.25'),(1758,227,'5','0.2'),(1759,227,'6','0.166'),(1760,227,'7','0.142'),(1761,227,'8','0.125'),(1774,127,'1','0.6'),(1775,127,'2','0.3'),(1776,127,'3','0.2'),(1777,127,'4','0.15'),(1778,127,'5','0.12'),(1779,127,'6','0.1');
/*!40000 ALTER TABLE `backyard_potential_syndicates` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-21 19:40:50
