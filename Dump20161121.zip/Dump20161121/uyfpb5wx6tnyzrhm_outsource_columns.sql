-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: q3vtafztappqbpzn.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: uyfpb5wx6tnyzrhm
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `outsource_columns`
--

DROP TABLE IF EXISTS `outsource_columns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `outsource_columns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT '0',
  `column_num` int(11) DEFAULT '0',
  `heading` varchar(100) DEFAULT '',
  `price` decimal(10,1) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  `verified` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `outsource_columns`
--

LOCK TABLES `outsource_columns` WRITE;
/*!40000 ALTER TABLE `outsource_columns` DISABLE KEYS */;
INSERT INTO `outsource_columns` VALUES (1,1,1,'First Name',0.0,0,0),(2,1,2,'Last Name',0.0,0,0),(3,1,3,'Title',0.0,0,0),(4,1,4,'Company',0.0,0,0),(5,1,5,'Email',0.4,1,0),(6,1,6,'Workphone',0.4,1,0),(7,1,7,'LinkedIn',0.2,1,0),(28,5,1,'First Name',0.0,0,0),(29,5,2,'Last Name',0.0,0,0),(30,5,3,'Title',0.0,0,0),(31,5,4,'Company',0.0,0,0),(32,5,5,'Email',0.3,1,1),(33,5,6,'Workphone',0.3,1,2),(34,6,1,'First Name',0.0,0,0),(35,6,2,'Last Name',0.0,0,0),(36,6,3,'Title',0.0,0,0),(37,6,4,'Company',0.0,0,0),(38,6,5,'Email',0.4,1,1),(39,6,6,'Workphone',0.4,1,2),(40,7,1,'First Name',0.0,0,0),(41,7,2,'Last Name',0.0,0,0),(42,7,3,'Title',0.0,0,0),(43,7,4,'Company',0.0,0,0),(44,7,5,'Email',0.4,1,1),(45,7,6,'Workphone',0.4,1,2),(46,7,8,'LinkedIn',0.2,1,3),(47,8,1,'First Name',0.0,0,0),(48,8,2,'Last Name',0.0,0,0),(49,8,3,'Title',0.0,0,0),(50,8,4,'Company',0.0,0,0),(51,8,5,'Email',0.4,1,1),(52,8,6,'Workphone',0.4,1,2),(53,8,8,'LinkedIn',0.0,1,3),(54,9,1,'First Name',0.0,0,0),(55,9,2,'Last Name',0.0,0,0),(56,9,3,'Title',0.0,0,0),(57,9,4,'Company',0.0,0,0),(58,9,5,'Email',0.5,1,1),(59,9,6,'Workphone',0.3,1,2),(60,9,8,'LinkedIn',0.2,1,3),(61,10,1,'First Name',0.0,0,0),(62,10,2,'Last Name',0.0,0,0),(63,10,3,'Title',0.0,0,0),(64,10,4,'Company',0.0,0,0),(65,10,5,'Email',0.4,1,1),(66,10,6,'Workphone',0.4,1,2),(67,11,1,'First Name',0.0,0,0),(68,11,2,'Last Name',0.0,0,0),(69,11,3,'Title',0.0,0,0),(70,11,4,'Company',0.0,0,0),(71,11,5,'Email',0.4,1,1),(72,11,6,'Workphone',0.3,1,2),(73,11,8,'LinkedIn',0.2,1,3),(74,12,1,'First Name',0.0,0,0),(75,12,2,'Last Name',0.0,0,0),(76,12,3,'Title',0.0,0,0),(77,12,4,'Company',0.0,0,0),(78,12,5,'Email',0.3,1,1),(79,12,6,'Workphone',0.3,1,2),(80,12,8,'LinkedIn',0.2,1,3),(81,13,1,'First Name',0.0,0,0),(82,13,2,'Last Name',0.0,0,0),(83,13,3,'Title',0.0,0,0),(84,13,4,'Company',0.0,0,0),(85,13,5,'Email',0.3,1,1),(86,13,6,'Workphone',0.3,1,2),(87,13,8,'LinkedIn',0.2,1,3);
/*!40000 ALTER TABLE `outsource_columns` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-21 19:23:41
