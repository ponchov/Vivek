-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: q3vtafztappqbpzn.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: uyfpb5wx6tnyzrhm
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `outsource_project`
--

DROP TABLE IF EXISTS `outsource_project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `outsource_project` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_name` varchar(50) DEFAULT NULL,
  `row_count` int(11) DEFAULT '0',
  `col_count` int(11) DEFAULT '0',
  `created_date` datetime DEFAULT NULL,
  `deadline` date NOT NULL,
  `status` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `outsource_project`
--

LOCK TABLES `outsource_project` WRITE;
/*!40000 ALTER TABLE `outsource_project` DISABLE KEYS */;
INSERT INTO `outsource_project` VALUES (1,'Gestion Proche',135,7,'2016-03-09 18:13:37','2016-06-21',0),(5,'Metro',98,6,'2016-06-28 19:09:20','2016-07-10',1),(6,'Metro Ent.',1576,6,'2016-07-07 13:30:55','2016-07-09',0),(7,'Semi-Ecomm.',94,7,'2016-07-07 21:50:59','2016-06-23',0),(8,'Consumer ',120,7,'2016-07-07 21:54:05','2016-07-30',1),(9,'MobileComm.',57,7,'2016-07-07 21:55:46','2016-07-01',0),(10,'Automot.',15,6,'2016-07-07 21:57:12','2016-06-03',0),(11,'Network1',55,7,'2016-07-07 21:58:30','2016-06-06',0),(12,'Cons.Product.',132,7,'2016-07-07 21:59:38','2016-05-10',0),(13,'Rest1',42,7,'2016-07-07 22:03:06','2016-04-21',0);
/*!40000 ALTER TABLE `outsource_project` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-21 19:27:58
