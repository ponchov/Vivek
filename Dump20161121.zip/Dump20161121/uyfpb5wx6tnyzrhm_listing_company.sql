-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: q3vtafztappqbpzn.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: uyfpb5wx6tnyzrhm
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `listing_company`
--

DROP TABLE IF EXISTS `listing_company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `listing_company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `type` varchar(20) NOT NULL,
  `lead_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `listing_company`
--

LOCK TABLES `listing_company` WRITE;
/*!40000 ALTER TABLE `listing_company` DISABLE KEYS */;
INSERT INTO `listing_company` VALUES (1,4298,'company',265),(2,4302,'company',265),(3,4293,'company',265),(4,4267,'company',265),(5,4270,'company',265),(6,4271,'company',265),(7,4272,'company',265),(8,4282,'company',265),(9,4279,'company',265),(10,4273,'company',265),(11,4285,'company',265),(12,4303,'company',265),(13,4276,'company',265),(14,4289,'company',265),(15,4301,'company',265),(16,4305,'company',265),(17,4277,'company',265),(18,4306,'company',265),(19,4291,'company',265),(20,407,'company',265),(21,4307,'company',265),(22,4288,'company',265),(23,4286,'company',265),(24,4299,'company',265),(25,4297,'company',265),(26,3,'company',265),(27,4292,'company',265),(29,4284,'company',265),(30,4308,'company',265),(31,4300,'company',265),(32,4280,'company',265),(33,4294,'company',265),(34,4296,'company',265),(35,4287,'company',265),(36,4268,'company',265),(37,4269,'company',265),(38,4283,'company',265),(39,4304,'company',265),(40,4274,'company',265),(42,3546,'company',265);
/*!40000 ALTER TABLE `listing_company` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-21 19:36:30
