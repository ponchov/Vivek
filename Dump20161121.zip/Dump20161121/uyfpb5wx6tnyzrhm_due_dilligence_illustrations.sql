-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: q3vtafztappqbpzn.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: uyfpb5wx6tnyzrhm
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `due_dilligence_illustrations`
--

DROP TABLE IF EXISTS `due_dilligence_illustrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `due_dilligence_illustrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patent_id` varchar(100) NOT NULL,
  `file` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `due_dilligence_illustrations`
--

LOCK TABLES `due_dilligence_illustrations` WRITE;
/*!40000 ALTER TABLE `due_dilligence_illustrations` DISABLE KEYS */;
INSERT INTO `due_dilligence_illustrations` VALUES (1,'US8909824','https://docs.google.com/presentation/d/1IDwh-8KuR-4YLmHzk01cTjpvhg5OdmSpLMoc0u-Dg8E/edit?usp=drivesdk'),(2,'US8386667','https://docs.google.com/presentation/d/1VcnO7jyD-PrT2GcqaIJbcz9FtZoCzte4HtixsWbPagc/edit?usp=drivesdk'),(3,'US7286944','https://docs.google.com/presentation/d/1esJfcv-5mi_YWQaIc-Y-OlYL8A-iDBg9o_ggPo-U1I8/edit?usp=drivesdk'),(4,'US7286945','https://docs.google.com/presentation/d/1GkxlmHPhI1R7E_7F12umHs9fTy_C6ZTduMAsgSEgq7s/edit?usp=drivesdk'),(5,'US7286946','https://docs.google.com/presentation/d/1ut-4VF58vCtST-8NOXZ6TzzoVz2l9VmrTcpRpJ2Yp0U/edit?usp=drivesdk'),(6,'US7286947','https://docs.google.com/presentation/d/1WAzCtW3TVpmd0Y_O2ZU2S3F8t7OnRiusg0tJPJ0tMtg/edit?usp=drivesdk'),(7,'US7286948','https://docs.google.com/presentation/d/1uZ8nE63Y3j3qfEyQD3QfStgBG1TkfdPMQjVSMol6Lqg/edit?usp=drivesdk'),(8,'US7123321','https://docs.google.com/presentation/d/1RyJL4MGjgrcnP28l71P7p2WXijsLRnvKNUnBjn1JjxM/edit?usp=drivesdk'),(9,'US7123322','https://docs.google.com/presentation/d/1s_sLefL7DjwIe33D0-Sl4W0xJVgp0caklx3_BHVDQR4/edit?usp=drivesdk'),(10,'US7123323','https://docs.google.com/presentation/d/19j2AaMrutDM-482b82OmvZxnNQImexzA7BxrJs3sdyY/edit?usp=drivesdk'),(11,'US7123324','https://docs.google.com/presentation/d/1kJb0IIYe1sKgJdmgulOfhvtMT6tYEb9MTWzaIjd4078/edit?usp=drivesdk'),(12,'US7123325','https://docs.google.com/presentation/d/1_FoTS9O4bvjK4ZXUdqNVUENAI0g6eQ6zPpJas_l4Sak/edit?usp=drivesdk'),(13,'US7123326','https://docs.google.com/presentation/d/1r2-OH9Nw-gsyenZzTqO8Np4d6cJAeWG2lMqGnBZgeEU/edit?usp=drivesdk'),(14,'US7557524','https://docs.google.com/presentation/d/1E5v1ySd7hqqVOyXPYJmoc3VFLC4sG9hxPuu_F7n3R_M/edit?usp=drivesdk'),(15,'US7945852','https://docs.google.com/presentation/d/1Hh2NKcvGVVXHu-ul8p2_12CZDjQMaWKTHZmRnf7Wojs/edit?usp=drivesdk'),(16,'US7626949','https://docs.google.com/presentation/d/1fnbKfclahYdoUkXgXl8enDed0cJA_X6R6iFsTiCczbA/edit?usp=drivesdk'),(17,'US9110563B2','https://docs.google.com/presentation/d/1SzYhtFwRyUUobT9fkjnovwyxazI7qk5SRbetA4W1GMQ/edit?usp=drivesdk'),(18,'US8902225B2','https://docs.google.com/presentation/d/1YMiLJnUQfqBjNhGkixSH6kqFw94FZ0P9TyHaVsfB40g/edit?usp=drivesdk'),(19,'US8730165B2','https://docs.google.com/presentation/d/1iBeKCmrzVEvZmMZX8SkE9fI590g3gLW8DEtkKXoWY70/edit?usp=drivesdk'),(20,'US8477098B2','https://docs.google.com/presentation/d/1wjFi4x0gQxKnnmSWyONoi-yiS--MO8kdeynyd3uAgoI/edit?usp=drivesdk'),(21,'US8319773B2','https://docs.google.com/presentation/d/1HPkIZPtMsQA_FN1ojp1qkxmH1tRdE_ZVK-w4SbpWUWo/edit?usp=drivesdk'),(22,'US20160026360A1','https://docs.google.com/presentation/d/1d1pUIItZP7SL43UE4lb1oQuiuXZi8XkBxXl76KKDics/edit?usp=drivesdk'),(23,'US7076037B1','https://docs.google.com/presentation/d/1u0TcDoPH9maClyl3_YV-k74oNxiMnOoyifH5d6DO1Xc/edit?usp=drivesdk'),(24,'US7953416B2','https://docs.google.com/presentation/d/1aRP3tukeaiwqdR8uZ2PtBP_8GmdYqOcrEoXVichvUac/edit?usp=drivesdk'),(25,'US8200231B2','https://docs.google.com/presentation/d/1Y27u6x1d4R6XygD-_TksvqzKvjC87uxuex8r4fmc2iI/edit?usp=drivesdk'),(26,'US20070269038A1','https://docs.google.com/presentation/d/1ulH_4-p-phRQlmRlh3FxDvGz-Oy9p6mDUfiFUQGSq70/edit?usp=drivesdk'),(27,'Expired:','https://docs.google.com/presentation/d/18UsQjTQwPDHRbXHquxTOf3W64i85QU0XQ0gkb0_bXMc/edit?usp=drivesdk'),(28,'WO2008008993','https://docs.google.com/presentation/d/1u-IhXGkMVqvRT1N9I_FhPameLpb8V7J1XeQo-Glf0zo/edit?usp=drivesdk'),(29,'AU2005319281','https://docs.google.com/presentation/d/1VbwP771gsLr1TljNBAVBtdkbaPx5NC_TDRw4vfTDdyo/edit?usp=drivesdk'),(30,'JP4774058B2','https://docs.google.com/presentation/d/1u6pjVV6IVbjq741We-7bFA5E3vRdJOiTWAvyIH45YPU/edit?usp=drivesdk'),(31,'AU2007272342','https://docs.google.com/presentation/d/1PS0rGB7Be11kQKZ1x3cTvKtviz2FctkWBoLnggarIaA/edit?usp=drivesdk'),(32,'CA2650115A1','https://docs.google.com/presentation/d/1nbU_FFY6HsJOR9S1XaEFDQJRuOTBcm9SLvVcWpURrM8/edit?usp=drivesdk'),(33,'US7403524B2','https://docs.google.com/presentation/d/1xKn9_AvuWV8Ks5eG4JN-miCTelbLwArD5s9kbr5dM58/edit?usp=drivesdk'),(34,'US7319673B1','https://docs.google.com/presentation/d/1E6IJDQOYB_4CuP2ZKNmF2FwAsvDyqOjN5_8-gC73G5M/edit?usp=drivesdk'),(35,'US7209437B1','https://docs.google.com/presentation/d/1QFBI47xtiJLFvgGlhyqTvk6FFM4Jslj-puODTWnQyGQ/edit?usp=drivesdk'),(36,'US7085241B1','https://docs.google.com/presentation/d/1GOnZLDs5VSIDBnNdLoIzAmBjxBw0NBLxo5et0cWBe1Q/edit?usp=drivesdk'),(37,'US6671263B1','https://docs.google.com/presentation/d/1tBdIN367bNXux1phTgWbEYWj4n4tFw8wONMl_TM6pSg/edit?usp=drivesdk'),(38,'US6665264B1','https://docs.google.com/presentation/d/1rsbZPlmCrEgVh-OwHhw_4MIAMNtfNHDLrfvZg0X6wbs/edit?usp=drivesdk'),(39,'US6584098B1','https://docs.google.com/presentation/d/1y0Y4B3WrpeRCiUXstduDQzVXnXQBEKxRFUDX0xrggSg/edit?usp=drivesdk'),(40,'US6538989B1','https://docs.google.com/presentation/d/13yvP-k-3CajohP3z8PGF16m28CzLwAFfmlejPMn95zA/edit?usp=drivesdk'),(41,'US20040125795A1','https://docs.google.com/presentation/d/1dGfrjTgrmY1ouJ49zmCwwbd-D0SXePAx_zSp_EVl1uw/edit?usp=drivesdk'),(42,'US20030147390 A1','https://docs.google.com/presentation/d/1n6m2cX8-cyK0oeq9XxvAAnWSE8U03_eZXqWFH4fg51c/edit?usp=drivesdk'),(43,'US20030107994A1','https://docs.google.com/presentation/d/1ywgb9H6Qm5k_cFGIxpxfBJHKvn4mIFC1_i4T3nEfDLg/edit?usp=drivesdk'),(44,'US20030021275 A1','https://docs.google.com/presentation/d/1KTMSeIjXDA3C2Ey7JyVS6ofA9rcYs98fwPx1H2j_CtI/edit?usp=drivesdk'),(45,'US7309823','https://docs.google.com/presentation/d/1gz_Q4CexPRMpHAnzKh135E9KbIlmcmND4XwvD32GYmc/edit?usp=drivesdk'),(46,'US7309825','https://docs.google.com/presentation/d/11vLd5PUF6D6EN5Bqb1PjFIqIsErRKkohITG9lJQCaJ0/edit?usp=drivesdk'),(47,'US7309826','https://docs.google.com/presentation/d/1CGxnVEVksfoxrcUZHn8GFvsW0NvSqoPj-uFe68V3hdg/edit?usp=drivesdk'),(48,'US7309827','https://docs.google.com/presentation/d/1teOQ9tUgs1xsum5ovOh9EUQENLbT9fvqfHA7zltfbVM/edit?usp=drivesdk'),(49,'US7309828','https://docs.google.com/presentation/d/1LPgZ7JcrotxuT8SG9ufzIcYeNjafxU5tK4w_7NH_mXI/edit?usp=drivesdk'),(50,'US7309829','https://docs.google.com/presentation/d/1LSHMWDl2qiZ-pWF5UE9p0GE44X4VTcQ1jWiFsK4iVj0/edit?usp=drivesdk'),(51,'US7309830','https://docs.google.com/presentation/d/16Eqx0-0itOkA8gAPAF4gb_fxojRYKd9tJZS1tQQCLMg/edit?usp=drivesdk'),(52,'US7309831','https://docs.google.com/presentation/d/1nsd4_zqqEhHNM31uwcOIV9QrZlNfjMj8iuxSuk5PdMg/edit?usp=drivesdk'),(53,'US20070199428A1','https://docs.google.com/presentation/d/1IOiAabpZ-hKXyB0joNZe5J_yJunVPbZ1tOwTLIak1x8/edit?usp=drivesdk'),(54,'US20060118158A1','https://docs.google.com/presentation/d/1YPN4MMLg7wveO5FCMa2ePszeGmtPva_YnOLB3MKfIJM/edit?usp=drivesdk'),(55,'US20040099127A1','https://docs.google.com/presentation/d/1BnNZRbGrys-6BxhIioCTwUs0ehWkXEbYbfC-XtTsZ0A/edit?usp=drivesdk'),(56,'US20050056139A1','https://docs.google.com/presentation/d/1XxjV9SAu0VWyRJOUpEPckZO-Pmj-HmUoBK8YDTXQQgc/edit?usp=drivesdk'),(57,'US20060048632A1','https://docs.google.com/presentation/d/11DheD2d1pODvrZS_5hbBkggRUyFCjv-QBKyNmOL5lQE/edit?usp=drivesdk'),(58,'US20050172781A1','https://docs.google.com/presentation/d/1Z72lBfiPWLKNr2dsSurLv51KBFhgoKcMV25qL2ZU82s/edit?usp=drivesdk'),(59,'US7557524B2','https://docs.google.com/presentation/d/1E5v1ySd7hqqVOyXPYJmoc3VFLC4sG9hxPuu_F7n3R_M/edit?usp=drivesdk'),(60,'US8909824B1','https://docs.google.com/presentation/d/1fiWMZrMFjLjkAf9fXLkv-WPy5JE8F3dJdEDH6NqyDx0/edit?usp=sharing'),(61,'US8386667B2','https://docs.google.com/presentation/d/1VcnO7jyD-PrT2GcqaIJbcz9FtZoCzte4HtixsWbPagc/edit?usp=sharing');
/*!40000 ALTER TABLE `due_dilligence_illustrations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-21 19:23:28
