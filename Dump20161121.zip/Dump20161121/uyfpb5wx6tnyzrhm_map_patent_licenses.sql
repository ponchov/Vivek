-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: q3vtafztappqbpzn.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: uyfpb5wx6tnyzrhm
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `map_patent_licenses`
--

DROP TABLE IF EXISTS `map_patent_licenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `map_patent_licenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patent_id` varchar(30) NOT NULL,
  `license_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `map_patent_licenses`
--

LOCK TABLES `map_patent_licenses` WRITE;
/*!40000 ALTER TABLE `map_patent_licenses` DISABLE KEYS */;
INSERT INTO `map_patent_licenses` VALUES (1,'US6845097',1),(2,'US6909878',1),(3,'US6957045',2),(4,'US7013112',2),(5,'US7016334',2),(6,'US6909878',4),(7,'US6909878',3),(9,'US6957045',1),(10,'US7013112',1),(11,'US7016334',1),(12,'US5379764',2),(13,'US5360004',2),(14,'US5460177',2),(15,'US5360004',3),(16,'US6283831',1),(17,'US6776588',1),(18,'US7653456',1),(19,'US6547651',1),(20,'US6789876',1),(21,'US6790431',1),(22,'US8338331',16),(23,'US8338340',16),(24,'US8338341',16),(25,'US8338342',16),(26,'US8338343',16),(27,'US8909824',7),(28,'US8386667',7);
/*!40000 ALTER TABLE `map_patent_licenses` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-21 19:29:47
