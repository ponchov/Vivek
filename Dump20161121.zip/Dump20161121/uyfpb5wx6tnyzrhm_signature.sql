-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: q3vtafztappqbpzn.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: uyfpb5wx6tnyzrhm
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `signature`
--

DROP TABLE IF EXISTS `signature`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `signature` (
  `id` int(11) NOT NULL,
  `signature` mediumtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `signature`
--

LOCK TABLES `signature` WRITE;
/*!40000 ALTER TABLE `signature` DISABLE KEYS */;
INSERT INTO `signature` VALUES (1,'<div dir=\"ltr\"><div><div dir=\"ltr\"><div><div dir=\"ltr\"><div><div dir=\"ltr\"><div><div dir=\"ltr\"><div style=\"font-size:12.8px\"><font color=\"#073763\"><b>#Name#</b></font></div><div style=\"font-size:12.8px\"><font color=\"#000000\">#Title#</font></div><div style=\"font-size:12.8px\"><font color=\"#000000\"><br></font></div><div style=\"font-size:12.8px\"><div style=\"font-size:12.8px\"><b style=\"color:rgb(7,55,99);font-size:12.8px\">Syndicated Patent Acquisitions Corp.</b></div><div style=\"font-size:12.8px\">One Market - Spear Tower, 36th Floor </div><div style=\"font-size:12.8px\">San Francisco, CA 94105  </div><div style=\"font-size:12.8px\">1-415-805-8818 #Direct# #Mobile#</div><div style=\"font-size:12.8px\">#Email#</div><div style=\"font-size:12.8px\"><a href=\"http://www.synpat.com/\" style=\"font-size:12.8px\" target=\"_blank\">www.synpat.com</a><span style=\"font-size:12.8px\"> </span></div><div style=\"font-size:12.8px\"><br></div><div style=\"font-size:12.8px\">This message is intended only for the individual or entity to which it is addressed. It may contain information that is confidential or privileged. If the reader of this message is not the intended recipient, you are hereby notified that any dissemination, sharing or copying of this e-mail is strictly prohibited. If you receive this e-mail in error, please notify Syndicated Patent Acquisitions Corp. immediately by telephone or email, and delete the material from any computer. Thank you.</div></div></div></div></div></div></div></div></div></div></div>');
/*!40000 ALTER TABLE `signature` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-21 19:32:53
