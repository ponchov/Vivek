-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: q3vtafztappqbpzn.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: uyfpb5wx6tnyzrhm
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `lead_reports`
--

DROP TABLE IF EXISTS `lead_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lead_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lead_id` int(11) NOT NULL,
  `draft_nda` int(11) NOT NULL DEFAULT '0',
  `cipo_approved` int(11) NOT NULL DEFAULT '0',
  `executed_nda` int(11) NOT NULL DEFAULT '0',
  `nda_execute` int(11) NOT NULL DEFAULT '0',
  `eou_folder` int(11) NOT NULL DEFAULT '0',
  `draft_a_ppa` int(11) NOT NULL DEFAULT '0',
  `execute_ppa` int(11) NOT NULL DEFAULT '0',
  `start_dd` int(11) NOT NULL DEFAULT '0',
  `order_damage` int(11) NOT NULL DEFAULT '0',
  `draft_pla` int(11) NOT NULL DEFAULT '0',
  `draft_participant` int(11) NOT NULL DEFAULT '0',
  `other_doc` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_reports`
--

LOCK TABLES `lead_reports` WRITE;
/*!40000 ALTER TABLE `lead_reports` DISABLE KEYS */;
INSERT INTO `lead_reports` VALUES (1,69,0,0,2,2,0,0,0,0,0,0,0,0),(3,77,0,0,0,0,0,0,0,0,0,0,0,0),(4,51,0,0,0,0,0,0,0,0,0,0,0,0),(5,78,0,0,0,0,0,2,0,0,0,0,0,0),(6,18,0,0,0,0,0,0,0,0,0,0,0,0),(7,90,0,0,1,0,2,0,1,0,0,0,0,0),(8,92,0,0,1,0,2,2,3,0,0,0,0,0),(9,90,0,0,0,0,0,2,2,0,0,0,0,0),(10,76,0,0,2,0,0,0,0,0,0,0,0,0),(11,9,0,0,0,0,0,0,0,0,0,0,0,0),(12,43,0,0,1,0,0,2,1,2,1,2,2,2),(13,138,0,0,0,0,0,0,0,0,0,0,0,0),(14,138,0,0,0,0,0,0,0,0,0,0,0,0),(15,137,0,0,0,0,0,0,0,0,0,0,0,2),(16,97,0,0,0,0,0,0,0,0,0,0,0,2),(17,147,0,0,0,0,0,0,0,0,0,0,0,0),(18,60,0,0,0,0,0,0,0,0,0,0,0,0),(19,148,0,0,0,0,0,0,0,0,0,0,0,0),(20,93,0,0,0,0,0,0,0,0,0,0,0,0),(21,155,0,0,0,0,0,0,0,0,0,0,0,0),(22,162,0,0,0,0,0,0,0,1,0,0,0,0),(23,133,0,0,0,0,0,0,0,0,0,0,0,0),(24,165,0,0,0,0,0,2,2,0,0,0,2,2),(25,88,0,0,0,0,0,2,2,0,0,0,0,0),(26,43,0,0,1,0,0,2,1,0,0,2,2,2),(27,141,0,0,0,0,0,2,0,0,0,0,0,0),(28,127,0,0,1,0,0,2,3,0,0,0,0,2),(29,127,0,0,1,0,0,2,3,0,0,0,0,2),(30,127,0,0,1,0,0,2,3,0,0,0,0,2),(31,188,0,0,0,0,0,2,2,0,0,0,0,0),(32,25,0,0,0,0,0,0,0,0,0,0,0,0),(33,182,0,0,0,0,0,0,0,0,0,0,0,0),(34,166,0,0,0,0,0,0,0,0,0,0,0,0),(35,217,0,0,0,0,0,0,0,0,0,0,0,2),(36,222,0,0,0,0,0,2,0,0,0,0,0,2),(37,143,0,0,0,0,0,0,0,0,0,0,0,0),(38,97,0,0,0,0,0,0,0,0,0,0,0,0),(39,221,0,0,0,0,0,0,0,0,0,0,0,0),(40,224,0,0,0,0,0,2,2,0,0,0,0,0),(41,226,0,0,0,0,0,0,0,0,0,0,0,0),(42,235,0,0,0,0,0,0,0,0,0,0,0,0),(43,236,0,0,0,0,0,0,0,0,0,0,0,0),(44,237,0,0,0,0,0,2,0,0,0,0,0,0),(45,239,0,0,0,0,0,0,0,0,0,0,0,0),(46,240,0,0,0,0,0,0,0,0,0,0,0,0),(47,230,0,0,0,0,0,0,0,0,0,0,0,0),(48,210,0,0,0,0,0,0,0,0,0,0,0,0),(49,251,0,0,0,0,0,2,2,0,0,0,0,0),(50,227,0,0,1,0,0,2,2,0,0,0,0,2),(51,93,0,0,0,0,0,0,0,0,0,0,0,0),(52,265,0,0,1,0,0,2,3,0,0,0,0,2),(53,275,0,0,1,0,0,2,0,0,0,0,0,0),(54,107,0,0,0,0,0,0,0,0,0,0,0,0),(55,150,0,0,0,0,0,0,0,0,0,0,0,0),(56,242,0,0,0,0,0,2,2,0,0,0,0,0),(57,106,0,0,0,0,0,0,0,0,0,0,0,0),(58,405,0,0,0,0,0,2,2,0,0,0,0,0),(59,201,0,0,0,0,0,0,0,0,0,0,0,0),(60,354,0,0,0,0,0,0,0,0,0,0,0,2),(61,404,0,0,0,0,0,2,0,0,0,0,0,0),(62,400,0,0,0,0,0,0,0,0,0,0,0,2),(63,186,0,0,0,0,0,0,0,0,0,0,0,2),(64,464,0,0,1,0,0,2,2,0,0,0,0,0),(65,464,0,0,1,0,0,2,2,0,0,0,0,0),(66,431,0,0,0,0,0,0,0,0,0,0,0,0),(67,467,0,0,0,0,0,0,0,0,0,0,0,2);
/*!40000 ALTER TABLE `lead_reports` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-21 19:35:39
