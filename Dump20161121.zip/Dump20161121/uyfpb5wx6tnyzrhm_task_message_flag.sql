-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: q3vtafztappqbpzn.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: uyfpb5wx6tnyzrhm
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `task_message_flag`
--

DROP TABLE IF EXISTS `task_message_flag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_message_flag` (
  `flag_id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL DEFAULT '0',
  `message_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`flag_id`),
  KEY `task_id` (`task_id`),
  KEY `message_id` (`message_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_message_flag`
--

LOCK TABLES `task_message_flag` WRITE;
/*!40000 ALTER TABLE `task_message_flag` DISABLE KEYS */;
INSERT INTO `task_message_flag` VALUES (1,52,1,1,2),(2,73,3,1,0),(6,73,10,10,2),(7,73,11,1,0),(8,73,12,10,2),(9,74,13,10,0),(10,96,14,12,0),(13,93,17,10,0),(14,79,18,12,0),(15,98,19,12,0),(18,98,22,10,1),(19,93,23,10,0),(20,118,24,10,0),(21,118,25,1,0),(24,118,28,10,1),(25,165,29,10,1),(28,164,32,10,1),(33,164,39,10,1),(34,164,40,10,1),(35,164,41,10,1),(36,179,45,12,0),(37,179,46,10,0),(38,179,47,10,0),(39,79,48,12,0),(41,97,50,12,0),(42,179,51,12,0),(43,179,52,10,0),(44,79,53,10,0),(47,163,56,12,0),(48,202,57,10,1),(49,198,58,10,1),(50,200,59,10,1),(51,201,60,10,1),(52,199,61,10,0),(54,197,64,10,0),(55,197,65,10,0),(56,197,66,10,0),(57,197,67,10,0),(58,206,68,1,0),(59,210,69,10,0),(60,79,70,12,0),(61,79,71,10,1),(62,211,72,10,1),(63,211,73,10,1),(64,206,74,1,0),(65,206,74,13,1),(66,206,74,12,0),(67,126,75,12,0),(68,245,76,1,0),(69,245,76,10,1),(70,246,77,12,0),(71,245,78,10,1),(72,246,79,1,0),(73,246,80,1,0),(74,283,81,10,0),(75,219,82,12,1),(76,219,82,10,0),(77,219,83,12,1),(78,219,83,1,0),(79,219,84,12,1),(80,219,84,10,0),(81,292,85,10,0),(82,306,86,10,0),(83,306,87,10,0),(84,306,88,10,0),(85,306,89,10,0),(86,310,90,1,0),(87,285,91,10,0),(88,312,92,1,0),(89,312,93,1,0),(90,312,94,1,0),(91,369,95,23,0),(92,386,96,23,0),(93,418,97,10,0),(94,423,98,26,0),(95,445,99,26,0),(96,415,100,10,0),(97,415,101,10,0),(98,440,102,26,1),(99,318,103,10,0),(100,318,103,18,1);
/*!40000 ALTER TABLE `task_message_flag` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-21 19:40:19
