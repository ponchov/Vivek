-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: q3vtafztappqbpzn.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: uyfpb5wx6tnyzrhm
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `free_precontacts`
--

DROP TABLE IF EXISTS `free_precontacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `free_precontacts` (
  `message` text,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `free_precontacts`
--

LOCK TABLES `free_precontacts` WRITE;
/*!40000 ALTER TABLE `free_precontacts` DISABLE KEYS */;
INSERT INTO `free_precontacts` VALUES ('Miriam Haller, Office Manager\nE-mail:    miriam@shaked-law.com\nWebsite: www.shaked-law.com\n \n\nElectra Building | 98 Yigal Alon St. | Tel Aviv 6789141 | Israel | Tel: +972-3-372-1114 | Fax: +972-3-372-1115',13),('Laura G Quatela	Executive vice president of intellectual property, office of the CEO	Alcatel-Lucent',17),('Dana Rao	Vice president, intellectual property and litigation	Adobe',18),('Michael LoCascio	Director of global IP strategy	BASF Catalysts',19),('Heath Hoglund\nChief patent counsel\nDolby Labs',20),('John Garland\nGarland IP\njohn@garlandips.com\n908.803.3741',21),('Mike Pellegrino, Founder\nIP Software, Inc. \n10333 North Meridian Street, Suite 150 \nIndianapolis, IN 46290\nPhone: 317.569.1313\nLearn more at www.ipanalytx.com.',27),('Renée C. Quinn\nChief Operating Officer\nIPWatchdog.com\nOffice: ?703-740-9835 ext 3\nMobile: 703-999-1128 ?',28),('Hala Al-Saeed\nPromevo - Google for Work Premier Partner \nAccount Manager\nhala.al-saeed@promevo.com\n(888) 380 - 1061 Ext.753',29),('Peter Harter\nFounder\nThe Farrington Group\n202-641-4778',30),('dweiler@royaltysource.com\n856-234-1199',31),('Andrew W. Spangler \nSpangler Law P.C. - Longview \n208 N. Green Street \nSte 300 \nLongview, TX 75601 \n903-753-9300 \n903-553-0403 (fax) \nspangler@spanglerlawpc.com',32),('Steven C. Carlson\nKasowitz, Benson, Torres & Friedman LLP\n333 Twin Dolphin Drive, Suite 200\nRedwood Shores, CA 94065\nTel. (650) 453-5414\nFax. (650) 368-9326\nscarlson@kasowitz.com\n',33),('\nMats Melén\nHead of Sales\n\nAppgyver Inc\n\n180 Sansome St , Floor 4, \nSan Francisco, \nCA 94104\n\nMerimiehenkatu 36 D\n00150 Helsinki\nFinland\n\nwww.appgyver.com\n\ne-mail: mats.melen@appgyver.com\nphone: +358407393008\nskype: matsmelen1\n',34),('http://goo.gl/0SHjZ4',35),('Pravin Shukla  \nDirector - Marketing and Business Development\nDirect: +919594907797\n\nResearchWire Knowledge Solutions\n#607 & 609 - Rupa Solitaire, Millennium Business Park\nNavi Mumbai, India - 400701\nwww.researchwire.in',36),('Alex Weihmann\nStrategic Partnerships\nConsero Group LLC\n4915 St. Elmo Ave., Ste. 100\nBethesda, MD 20814\n\nT:  (240) 743-2360\nM: (484) 319-7496\nwww.consero.com',37);
/*!40000 ALTER TABLE `free_precontacts` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-21 19:40:03
