-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: q3vtafztappqbpzn.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: uyfpb5wx6tnyzrhm
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `chart_middles`
--

DROP TABLE IF EXISTS `chart_middles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chart_middles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `license_id` int(11) NOT NULL,
  `technologies` varchar(400) NOT NULL,
  `data` int(11) NOT NULL,
  `tooltip` varchar(300) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52104 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chart_middles`
--

LOCK TABLES `chart_middles` WRITE;
/*!40000 ALTER TABLE `chart_middles` DISABLE KEYS */;
INSERT INTO `chart_middles` VALUES (1399,126,'D',25,''),(1400,126,'S',45,''),(1401,126,'E',15,''),(1402,126,'L',85,''),(1403,126,'N',64,''),(1416,127,'Android',150,''),(1417,127,'window',50,''),(1418,127,'iPhone',250,''),(1475,118,'Receivers\' fragments processing',1,''),(1476,118,'Single timer processing',1,''),(1477,118,'Base Stations',1,''),(1478,118,'Handsets',1,''),(1862,124,'Lighting Group Control Switching',1,''),(1863,124,'Luminocity Level Maintenance',1,''),(1864,124,'Computer Control Lighting Group Devices',1,''),(1865,159,'Lighting Group Control Switching',1,''),(1866,159,'Luminocity Level Maintenance',1,''),(1867,159,'Computer Control Lighting Group Devices',1,''),(50606,6,'Explanation1',1,''),(50607,6,'Explanation2 as dsa dsa d sadsa dsa d sad sad sad sad sad sa dsa d sad sadsadsadsadsadsadsadsa dsa dsad sa d sadsa d sadsa d sad sadsad sadsad sadsadsadsadsadsadsadsadsadsadsadsa dsadsa dsa dsa dasdsadsa dsa dsa dsa d sadsa d sad sad sad sadsa dsa dsadsa dsa d sad sad sad sad sa d sadsa d sad sad sadsad sad sad sad sa dsa ds adsad sa dsa dsa dsa d sad sads ad sadsa das d asd adsa d',1,''),(50616,156,'Advertising Systems/Solutions',3,'Web systems aimed to help vendors be seen by potential customers based on different factors and parameters.'),(50617,156,'Toll-Free Call Routing',3,'Telephone numbers in which the calling party is not charged for the call by the telephone carrier.'),(50618,156,'Online Search Portals',3,'Specially designed web site that brings information together from diverse sources in a uniform way.'),(50619,156,'Vanity Numbers - Call Routing',3,'A telephone number for which a subscriber requests an easily remembered sequence of numbers for marketing purposes.'),(50623,171,'Proximity sensoring',1,'6'),(51371,153,'Financial Services',1,''),(51372,153,'Internet TV',1,'Digital distribution of television content, such as TV shows, via the public Internet. Digital distribution of television content, such as TV shows, via the public Internet.Digital distribution of television content'),(51373,153,'Speech Signal Processing',2,'When a user interacts with the holographic image, the sensors sense the user interaction based on quadrilateral angle navigation. The information corresponding to the user interaction is provided to the processor '),(51374,153,'HDTV',2,''),(51375,153,'GPS',4,''),(51376,153,'Cameras',1,''),(51377,153,'Notebook',1,''),(51737,172,'Telephonic Communications',4,'Standard audio handling, Video handling, Telecommunications Call Centre Environment\n'),(51738,172,'Computer Networks',6,'Routers and Switches '),(52101,176,'Networking',3,'Error Correction, Fault detection & recovery, Data Processing System, Multiplex Communication, Data switching networks, '),(52102,176,'Computer Networks',3,'Switching, Synchronization, clock signals, Routing, SONET'),(52103,176,'Telephonic Communications',3,'\nTelegraphic Communication');
/*!40000 ALTER TABLE `chart_middles` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-21 19:39:23
