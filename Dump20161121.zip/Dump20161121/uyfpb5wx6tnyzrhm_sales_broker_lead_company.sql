-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: q3vtafztappqbpzn.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: uyfpb5wx6tnyzrhm
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sales_broker_lead_company`
--

DROP TABLE IF EXISTS `sales_broker_lead_company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales_broker_lead_company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `broker_company_id` int(11) DEFAULT NULL,
  `lead_id` int(11) DEFAULT NULL,
  `sales_company_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_broker_lead_company`
--

LOCK TABLES `sales_broker_lead_company` WRITE;
/*!40000 ALTER TABLE `sales_broker_lead_company` DISABLE KEYS */;
INSERT INTO `sales_broker_lead_company` VALUES (7,1,127,136),(8,1,127,134),(9,1,127,110),(10,1,127,132),(11,1,127,133),(12,1,127,135),(13,1,127,137),(14,1,127,138),(15,1,127,139),(16,1,127,140),(17,1,127,141),(18,1,127,143),(19,1,127,145),(20,1,127,147),(21,1,127,148),(22,1,127,131),(23,1,127,109),(24,1,127,129),(25,1,127,111),(26,1,127,113),(27,1,127,114),(28,1,127,115),(29,1,127,116),(30,1,127,117),(31,1,127,119),(32,1,127,34),(33,1,127,124),(34,1,127,125),(35,1,127,127),(36,1,127,151),(37,1,127,112),(38,1,127,249),(39,1,127,259),(40,1,127,258),(41,1,127,385),(42,1,127,253),(43,1,127,230),(44,1,127,235),(45,1,127,229),(46,1,127,271),(47,1,127,96),(48,1,127,231),(49,1,127,392),(50,1,127,232),(51,1,127,156),(52,1,127,157),(53,1,127,160),(54,1,127,161),(55,1,127,153),(56,1,127,163),(57,1,127,164),(58,1,127,167),(59,1,127,166),(60,1,127,152),(61,1,127,195),(62,1,127,154),(63,1,127,107),(64,1,127,265),(65,1,127,126),(66,1,127,118),(67,1,127,146),(68,1,127,155),(69,1,127,150),(70,1,127,162),(71,3483,237,3474),(72,3483,237,376),(73,3483,237,33),(74,3483,237,13),(75,3483,263,1);
/*!40000 ALTER TABLE `sales_broker_lead_company` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-21 19:44:05
